import { useState, useEffect } from 'react';
import {
  ScrollView,
  FlexboxLayout,
  Image,
  Label,
  Button,
  GridLayout,
  Screen,
  Animation,
  GestureTypes,
  PanGestureEventData
} from '@nativescript/core';
import { useNavigation } from '@react-navigation/native';
import { imageCacheManager } from '../utils/imageCache';

const featuredCourses = [
  {
    id: 1,
    title: 'Advanced Web Development',
    instructor: 'Dr. Sarah Chen',
    rating: 4.9,
    students: 1500,
    price: 199,
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
  },
  // ... other courses
];

export default function HomePage() {
  const navigation = useNavigation();
  const [cachedImages, setCachedImages] = useState({});

  useEffect(() => {
    // Preload images
    const preloadImages = async () => {
      const imageUrls = featuredCourses.map(course => course.image);
      const cached = {};
      await Promise.all(
        imageUrls.map(async (url) => {
          cached[url] = await imageCacheManager.preloadImage(url);
        })
      );
      setCachedImages(cached);
    };

    preloadImages();
  }, []);

  const onCourseTap = (courseId: number) => {
    navigation.navigate('CourseDetails', { courseId });
  };

  const onPanCourseCard = (args: PanGestureEventData, courseId: number) => {
    const card = args.object;
    if (args.state === 1) { // Down
      new Animation([{
        target: card,
        scale: { x: 0.95, y: 0.95 },
        duration: 100
      }]).play();
    } else if (args.state === 3) { // Up
      new Animation([{
        target: card,
        scale: { x: 1, y: 1 },
        duration: 100
      }]).play().then(() => {
        if (Math.abs(args.deltaX) < 5 && Math.abs(args.deltaY) < 5) {
          onCourseTap(courseId);
        }
      });
    }
  };

  return (
    <Screen>
      <ScrollView>
        {/* Hero Section */}
        <FlexboxLayout flexDirection="column" padding={20}>
          <Label
            text="Unlock Your Potential"
            className="text-3xl font-bold text-center"
            textWrap={true}
          />
          <Label
            text="Discover, learn, and build your future"
            className="text-xl text-center text-gray-400 m-t-10"
            textWrap={true}
          />
          
          <FlexboxLayout flexDirection="row" justifyContent="center" margin={20}>
            <Button
              text="Explore Courses"
              className="cosmic-button"
              onTap={() => navigation.navigate('Courses')}
            />
            <Button
              text="Try SkillMap"
              className="cosmic-button-outline m-l-10"
              onTap={() => navigation.navigate('SkillMap')}
            />
          </FlexboxLayout>
        </FlexboxLayout>

        {/* Featured Courses */}
        <Label
          text="Featured Courses"
          className="text-2xl font-bold m-l-20 m-b-10"
        />
        
        <GridLayout rows="auto" columns="*" padding={10}>
          {featuredCourses.map((course) => (
            <FlexboxLayout
              key={course.id}
              className="course-card"
              margin={10}
              onPan={(args) => onPanCourseCard(args, course.id)}
            >
              <Image
                src={cachedImages[course.image] || course.image}
                height={200}
                stretch="aspectFill"
                className="rounded-t-lg"
              />
              
              <FlexboxLayout flexDirection="column" padding={15}>
                <Label
                  text={course.title}
                  className="text-xl font-bold"
                  textWrap={true}
                />
                <Label
                  text={`by ${course.instructor}`}
                  className="text-gray-400"
                />
                
                <FlexboxLayout justifyContent="space-between" marginTop={10}>
                  <Label
                    text={`${course.students} students`}
                    className="text-gray-400"
                  />
                  <Label
                    text={`$${course.price}`}
                    className="text-xl font-bold"
                  />
                </FlexboxLayout>
              </FlexboxLayout>
            </FlexboxLayout>
          ))}
        </GridLayout>
      </ScrollView>
    </Screen>
  );
}