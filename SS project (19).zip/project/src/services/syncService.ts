import { api } from './api';
import { offlineManager } from '../utils/offline';

interface SyncItem {
  id: string;
  type: string;
  action: string;
  data: any;
  timestamp: number;
  retries: number;
}

class SyncService {
  private static instance: SyncService;
  private syncQueue: SyncItem[] = [];
  private isSyncing = false;
  private maxRetries = 3;
  private syncInterval = 60000; // 1 minute

  private constructor() {
    this.loadQueue();
    this.setupAutoSync();
  }

  static getInstance(): SyncService {
    if (!SyncService.instance) {
      SyncService.instance = new SyncService();
    }
    return SyncService.instance;
  }

  private async loadQueue(): Promise<void> {
    const savedQueue = await offlineManager.loadOfflineData('sync_queue');
    if (savedQueue) {
      this.syncQueue = savedQueue;
    }
  }

  private async saveQueue(): Promise<void> {
    await offlineManager.saveOfflineData('sync_queue', this.syncQueue);
  }

  private setupAutoSync(): void {
    setInterval(() => this.sync(), this.syncInterval);
  }

  async queueForSync(item: Omit<SyncItem, 'id' | 'timestamp' | 'retries'>): Promise<void> {
    const syncItem: SyncItem = {
      ...item,
      id: Date.now().toString(),
      timestamp: Date.now(),
      retries: 0,
    };

    this.syncQueue.push(syncItem);
    await this.saveQueue();
    this.sync();
  }

  async sync(): Promise<void> {
    if (this.isSyncing || this.syncQueue.length === 0) return;

    this.isSyncing = true;

    try {
      const items = [...this.syncQueue];
      for (const item of items) {
        try {
          await this.processSyncItem(item);
          this.syncQueue = this.syncQueue.filter(i => i.id !== item.id);
        } catch (error) {
          console.error(`Error syncing item ${item.id}:`, error);
          item.retries++;
          
          if (item.retries >= this.maxRetries) {
            this.syncQueue = this.syncQueue.filter(i => i.id !== item.id);
            // Store failed items for later recovery if needed
            await offlineManager.saveOfflineData(
              'failed_sync_items',
              [...(await offlineManager.loadOfflineData('failed_sync_items') || []), item]
            );
          }
        }
      }
    } finally {
      this.isSyncing = false;
      await this.saveQueue();
    }
  }

  private async processSyncItem(item: SyncItem): Promise<void> {
    switch (item.type) {
      case 'note':
        if (item.action === 'create') {
          await api.post('/notes', item.data);
        } else if (item.action === 'update') {
          await api.put(`/notes/${item.data.id}`, item.data);
        }
        break;

      case 'course_progress':
        await api.post(`/courses/${item.data.courseId}/progress`, {
          progress: item.data.progress,
        });
        break;

      case 'chat_message':
        await api.post(`/chat/${item.data.conversationId}/messages`, {
          content: item.data.content,
        });
        break;

      default:
        throw new Error(`Unknown sync item type: ${item.type}`);
    }
  }
}

export const syncService = SyncService.getInstance();