import { api } from './api';

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  courseUpdates: boolean;
  studyGroups: boolean;
  messages: boolean;
  achievements: boolean;
}

export const notificationService = {
  async getNotifications(page = 1, limit = 20): Promise<any[]> {
    return api.get('/notifications', { params: { page, limit } });
  },

  async markAsRead(notificationIds: string[]): Promise<void> {
    return api.post('/notifications/read', { notificationIds });
  },

  async updatePreferences(preferences: Partial<NotificationPreferences>): Promise<void> {
    return api.put('/notifications/preferences', preferences);
  },

  async getPreferences(): Promise<NotificationPreferences> {
    return api.get('/notifications/preferences');
  },

  async registerPushToken(token: string): Promise<void> {
    return api.post('/notifications/push-token', { token });
  }
};