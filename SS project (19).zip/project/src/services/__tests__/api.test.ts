import { api } from '../api';
import axios from 'axios';
import { store } from '../../store/store';

jest.mock('axios');
jest.mock('../../store/store');

describe('ApiService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('should add auth token to requests when available', async () => {
    localStorage.setItem('authToken', 'test-token');
    const mockAxios = axios.create as jest.Mock;
    const mockGet = jest.fn().mockResolvedValue({ data: {} });
    
    mockAxios.mockReturnValue({
      interceptors: {
        request: { use: jest.fn() },
        response: { use: jest.fn() },
      },
      get: mockGet,
    });

    await api.get('/test');

    expect(mockGet).toHaveBeenCalledWith('/test', expect.objectContaining({
      headers: expect.objectContaining({
        Authorization: 'Bearer test-token',
      }),
    }));
  });

  it('should handle token refresh on 401 error', async () => {
    localStorage.setItem('refreshToken', 'refresh-token');
    const mockAxios = axios.create as jest.Mock;
    const mockPost = jest.fn()
      .mockRejectedValueOnce({ 
        response: { status: 401 },
        config: { headers: {} },
      })
      .mockResolvedValueOnce({
        data: { accessToken: 'new-token' },
      })
      .mockResolvedValueOnce({ data: 'success' });

    mockAxios.mockReturnValue({
      interceptors: {
        request: { use: jest.fn() },
        response: { use: jest.fn() },
      },
      post: mockPost,
    });

    const result = await api.post('/test');

    expect(result).toBe('success');
    expect(localStorage.getItem('authToken')).toBe('new-token');
  });

  it('should retry failed requests with exponential backoff', async () => {
    const mockAxios = axios.create as jest.Mock;
    const mockGet = jest.fn()
      .mockRejectedValueOnce({ response: { status: 500 } })
      .mockRejectedValueOnce({ response: { status: 500 } })
      .mockResolvedValueOnce({ data: 'success' });

    mockAxios.mockReturnValue({
      interceptors: {
        request: { use: jest.fn() },
        response: { use: jest.fn() },
      },
      get: mockGet,
    });

    const result = await api.get('/test');

    expect(result).toBe('success');
    expect(mockGet).toHaveBeenCalledTimes(3);
  });

  it('should handle rate limiting with retry-after header', async () => {
    const mockAxios = axios.create as jest.Mock;
    const mockPost = jest.fn()
      .mockRejectedValueOnce({
        response: {
          status: 429,
          headers: { 'retry-after': '1' },
        },
      })
      .mockResolvedValueOnce({ data: 'success' });

    mockAxios.mockReturnValue({
      interceptors: {
        request: { use: jest.fn() },
        response: { use: jest.fn() },
      },
      post: mockPost,
    });

    const result = await api.post('/test');

    expect(result).toBe('success');
    expect(mockPost).toHaveBeenCalledTimes(2);
  });

  it('should dispatch logout on refresh token failure', async () => {
    localStorage.setItem('refreshToken', 'invalid-token');
    const mockAxios = axios.create as jest.Mock;
    const mockPost = jest.fn()
      .mockRejectedValueOnce({
        response: { status: 401 },
        config: { headers: {} },
      })
      .mockRejectedValueOnce(new Error('Invalid refresh token'));

    mockAxios.mockReturnValue({
      interceptors: {
        request: { use: jest.fn() },
        response: { use: jest.fn() },
      },
      post: mockPost,
    });

    try {
      await api.post('/test');
    } catch (error) {
      expect(store.dispatch).toHaveBeenCalledWith(expect.any(Function));
    }
  });
});