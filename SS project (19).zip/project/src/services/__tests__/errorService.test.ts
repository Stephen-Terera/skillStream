import { errorService } from '../errorService';
import { analyticsService } from '../analyticsService';

jest.mock('../analyticsService');

describe('ErrorService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('handleError', () => {
    it('should track error in analytics', async () => {
      const error = new Error('Test error');
      await errorService.handleError(error, 'test context');

      expect(analyticsService.trackEvent).toHaveBeenCalledWith(
        'error_occurred',
        expect.objectContaining({
          message: 'Test error',
          context: 'test context'
        })
      );
    });

    it('should maintain error queue size limit', async () => {
      // Fill queue beyond limit
      for (let i = 0; i < 150; i++) {
        await errorService.handleError(new Error(`Error ${i}`));
      }

      const recentErrors = errorService.getRecentErrors();
      expect(recentErrors.length).toBeLessThanOrEqual(100);
    });
  });

  describe('error management', () => {
    it('should clear error queue', () => {
      errorService.handleError(new Error('Test error'));
      errorService.clearErrors();
      
      expect(errorService.getRecentErrors()).toHaveLength(0);
    });
  });
});