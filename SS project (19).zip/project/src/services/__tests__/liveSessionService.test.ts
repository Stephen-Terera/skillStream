import { liveSessionService } from '../liveSessionService';
import { api } from '../api';
import { realtimeService } from '../realtimeService';
import { errorService } from '../errorService';

jest.mock('../api');
jest.mock('../realtimeService');
jest.mock('../errorService');

describe('LiveSessionService', () => {
  let mockMediaDevices: any;

  beforeEach(() => {
    mockMediaDevices = {
      getUserMedia: jest.fn().mockResolvedValue({
        getTracks: () => [{}, {}]
      })
    };
    global.navigator.mediaDevices = mockMediaDevices;
    jest.clearAllMocks();
  });

  describe('startSession', () => {
    it('should set up media stream and join session', async () => {
      const sessionId = 'test-session';
      const mockParticipants = [{ id: 'user1' }];
      const mockIceServers = [{ urls: 'stun:stun.test.com' }];

      (api.post as jest.Mock).mockResolvedValue({
        participants: mockParticipants,
        iceServers: mockIceServers
      });

      await liveSessionService.startSession(sessionId);

      expect(mockMediaDevices.getUserMedia).toHaveBeenCalled();
      expect(api.post).toHaveBeenCalledWith(`/sessions/${sessionId}/join`);
      expect(realtimeService.joinRoom).toHaveBeenCalledWith(sessionId);
    });

    it('should handle media access errors', async () => {
      mockMediaDevices.getUserMedia.mockRejectedValue(new Error('Media access denied'));

      await expect(liveSessionService.startSession('test-session'))
        .rejects.toThrow('Failed to access media devices');

      expect(errorService.handleError).toHaveBeenCalled();
    });
  });

  describe('whiteboard features', () => {
    it('should add whiteboard object and broadcast update', async () => {
      const mockObject = {
        type: 'path',
        data: { points: [] },
        createdBy: 'user1'
      };

      (api.post as jest.Mock).mockResolvedValue({
        data: { ...mockObject, id: '123' }
      });

      await liveSessionService.addWhiteboardObject(mockObject);

      expect(api.post).toHaveBeenCalledWith(
        expect.stringContaining('/whiteboard'),
        mockObject
      );
      expect(realtimeService.sendMessage).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          type: 'whiteboard-update'
        })
      );
    });
  });

  describe('poll management', () => {
    it('should create and broadcast poll', async () => {
      const question = 'Test question';
      const options = ['Option 1', 'Option 2'];
      const mockPoll = {
        id: '123',
        question,
        options: options.map(text => ({ text, votes: 0 }))
      };

      (api.post as jest.Mock).mockResolvedValue(mockPoll);

      const result = await liveSessionService.createPoll(question, options);

      expect(result).toEqual(mockPoll);
      expect(realtimeService.sendMessage).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          type: 'poll-created',
          poll: mockPoll
        })
      );
    });
  });

  describe('breakout rooms', () => {
    it('should create and broadcast breakout rooms', async () => {
      const mockRooms = [
        { id: 'room1', name: 'Room 1', participants: [] }
      ];

      (api.post as jest.Mock).mockResolvedValue(mockRooms);

      const result = await liveSessionService.createBreakoutRooms(1, 600);

      expect(result).toEqual(mockRooms);
      expect(realtimeService.sendMessage).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          type: 'breakout-rooms-created',
          rooms: mockRooms
        })
      );
    });
  });
});