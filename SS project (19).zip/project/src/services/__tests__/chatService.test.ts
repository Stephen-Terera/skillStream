import { chatService } from '../chatService';
import { api } from '../api';

jest.mock('../api');

describe('chatService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getMessages', () => {
    it('should fetch messages for a conversation', async () => {
      const mockMessages = [
        { id: '1', content: 'Test message' }
      ];
      (api.get as jest.Mock).mockResolvedValue(mockMessages);

      const result = await chatService.getMessages('conv-123');

      expect(result).toEqual(mockMessages);
      expect(api.get).toHaveBeenCalledWith('/chat/conv-123/messages');
    });
  });

  describe('sendMessage', () => {
    it('should send a message', async () => {
      const mockMessage = { id: '1', content: 'Hello' };
      (api.post as jest.Mock).mockResolvedValue(mockMessage);

      const result = await chatService.sendMessage('conv-123', 'Hello');

      expect(result).toEqual(mockMessage);
      expect(api.post).toHaveBeenCalledWith('/chat/conv-123/messages', { content: 'Hello' });
    });
  });

  describe('markAsRead', () => {
    it('should mark messages as read', async () => {
      const messageIds = ['msg-1', 'msg-2'];
      await chatService.markAsRead(messageIds);

      expect(api.post).toHaveBeenCalledWith('/chat/messages/read', { messageIds });
    });
  });
});