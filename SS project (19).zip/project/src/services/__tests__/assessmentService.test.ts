```typescript
import { assessmentService } from '../assessmentService';
import { api } from '../api';
import { errorService } from '../errorService';

jest.mock('../api');
jest.mock('../errorService');

describe('AssessmentService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('assessment creation', () => {
    it('should create assessment', async () => {
      const mockAssessment = {
        title: 'Test Assessment',
        description: 'Test description',
        questions: [],
        passingScore: 70,
        attempts: 2
      };

      (api.post as jest.Mock).mockResolvedValue({
        ...mockAssessment,
        id: '123'
      });

      const result = await assessmentService.createAssessment(mockAssessment);

      expect(result).toEqual(expect.objectContaining({
        id: '123',
        ...mockAssessment
      }));
      expect(api.post).toHaveBeenCalledWith('/assessments', mockAssessment);
    });
  });

  describe('assessment submission', () => {
    it('should handle submission process', async () => {
      const mockSubmission = {
        id: 'sub123',
        assessmentId: 'ass123',
        startTime: new Date().toISOString()
      };

      (api.post as jest.Mock).mockResolvedValue(mockSubmission);

      const result = await assessmentService.startAssessment('ass123');

      expect(result).toEqual(mockSubmission);
      expect(api.post).toHaveBeenCalledWith('/assessments/ass123/start');
    });

    it('should submit answers', async () => {
      await assessmentService.submitAnswer('sub123', 'q1', 'answer');

      expect(api.post).toHaveBeenCalledWith(
        '/submissions/sub123/answers',
        {
          questionId: 'q1',
          answer: 'answer'
        }
      );
    });
  });

  describe('grading', () => {
    it('should grade submission', async () => {
      const mockGradedSubmission = {
        id: 'sub123',
        score: 85
      };

      (api.post as jest.Mock).mockResolvedValue(mockGradedSubmission);

      const result = await assessmentService.gradeSubmission('sub123');

      expect(result).toEqual(mockGradedSubmission);
      expect(api.post).toHaveBeenCalledWith('/submissions/sub123/grade');
    });
  });

  describe('export features', () => {
    it('should export to SCORM', async () => {
      const mockUrl = 'https://example.com/scorm.zip';
      (api.post as jest.Mock).mockResolvedValue({ url: mockUrl });

      const result = await assessmentService.exportToSCORM('ass123');

      expect(result).toBe(mockUrl);
      expect(api.post).toHaveBeenCalledWith('/assessments/ass123/export/scorm');
    });

    it('should export to xAPI', async () => {
      const mockStatement = {
        actor: { name: 'Test User' },
        verb: { id: 'completed', display: { 'en-US': 'completed' } },
        object: { id: 'ass123', definition: { type: 'assessment' } }
      };

      (api.post as jest.Mock).mockResolvedValue(mockStatement);

      const result = await assessmentService.exportToXAPI('sub123');

      expect(result).toEqual(mockStatement);
      expect(api.post).toHaveBeenCalledWith('/submissions/sub123/export/xapi');
    });
  });
});
```