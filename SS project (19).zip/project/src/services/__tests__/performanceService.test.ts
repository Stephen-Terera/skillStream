import { performanceService } from '../performanceService';
import { analyticsService } from '../analyticsService';

jest.mock('../analyticsService');

describe('PerformanceService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    performanceService.clearMetrics();
  });

  describe('performance measurement', () => {
    it('should measure execution time', () => {
      const endMeasure = performanceService.startMeasure('test-metric');
      
      // Simulate some work
      for (let i = 0; i < 1000000; i++) {}
      
      endMeasure();

      const metrics = performanceService.getMetrics('test-metric');
      expect(metrics.samples).toBe(1);
      expect(metrics.average).toBeGreaterThan(0);
    });

    it('should track performance issues', () => {
      const endMeasure = performanceService.startMeasure('slow-operation');
      
      // Mock performance.now to simulate slow operation
      jest.spyOn(performance, 'now')
        .mockReturnValueOnce(0)
        .mockReturnValueOnce(2000);

      endMeasure();

      expect(analyticsService.trackEvent).toHaveBeenCalledWith(
        'performance_issue',
        expect.objectContaining({
          metric: 'slow-operation',
          value: expect.any(Number)
        })
      );
    });
  });

  describe('metrics calculation', () => {
    it('should calculate correct statistics', () => {
      const values = [100, 200, 300];
      values.forEach(value => {
        const endMeasure = performanceService.startMeasure('stats-test');
        jest.spyOn(performance, 'now')
          .mockReturnValueOnce(0)
          .mockReturnValueOnce(value);
        endMeasure();
      });

      const metrics = performanceService.getMetrics('stats-test');
      expect(metrics).toEqual({
        average: 200,
        min: 100,
        max: 300,
        samples: 3
      });
    });
  });
});