import { studyGroupService } from '../studyGroupService';
import { api } from '../api';

jest.mock('../api');

describe('studyGroupService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getStudyGroups', () => {
    it('should fetch study groups with filters', async () => {
      const mockGroups = [{ id: '1', name: 'Test Group' }];
      (api.get as jest.Mock).mockResolvedValue(mockGroups);

      const filters = { courseId: 'course-123' };
      const result = await studyGroupService.getStudyGroups(filters);

      expect(result).toEqual(mockGroups);
      expect(api.get).toHaveBeenCalledWith('/study-groups', { params: filters });
    });
  });

  describe('createStudyGroup', () => {
    it('should create a new study group', async () => {
      const mockGroup = { id: '1', name: 'New Group' };
      (api.post as jest.Mock).mockResolvedValue(mockGroup);

      const groupData = { name: 'New Group', courseId: 'course-123' };
      const result = await studyGroupService.createStudyGroup(groupData);

      expect(result).toEqual(mockGroup);
      expect(api.post).toHaveBeenCalledWith('/study-groups', groupData);
    });
  });

  describe('joinStudyGroup', () => {
    it('should join a study group', async () => {
      await studyGroupService.joinStudyGroup('group-123');

      expect(api.post).toHaveBeenCalledWith('/study-groups/group-123/join');
    });
  });
});