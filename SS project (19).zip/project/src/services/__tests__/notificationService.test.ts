import { notificationService } from '../notificationService';
import { api } from '../api';

jest.mock('../api');

describe('notificationService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getNotifications', () => {
    it('should fetch notifications with pagination', async () => {
      const mockNotifications = [{ id: '1', message: 'Test notification' }];
      (api.get as jest.Mock).mockResolvedValue(mockNotifications);

      const result = await notificationService.getNotifications(2, 10);

      expect(result).toEqual(mockNotifications);
      expect(api.get).toHaveBeenCalledWith('/notifications', { params: { page: 2, limit: 10 } });
    });
  });

  describe('updatePreferences', () => {
    it('should update notification preferences', async () => {
      const preferences = { email: true, push: false };
      await notificationService.updatePreferences(preferences);

      expect(api.put).toHaveBeenCalledWith('/notifications/preferences', preferences);
    });
  });

  describe('registerPushToken', () => {
    it('should register push notification token', async () => {
      const token = 'device-token-123';
      await notificationService.registerPushToken(token);

      expect(api.post).toHaveBeenCalledWith('/notifications/push-token', { token });
    });
  });
});