import { cacheService } from '../cacheService';

describe('CacheService', () => {
  beforeEach(() => {
    cacheService.clear();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('cache operations', () => {
    it('should store and retrieve values', () => {
      cacheService.set('test-key', 'test-value');
      expect(cacheService.get('test-key')).toBe('test-value');
    });

    it('should respect TTL', () => {
      cacheService.set('test-key', 'test-value', 1000); // 1 second TTL
      
      expect(cacheService.get('test-key')).toBe('test-value');
      
      jest.advanceTimersByTime(1100);
      
      expect(cacheService.get('test-key')).toBeNull();
    });

    it('should handle cache cleanup', () => {
      cacheService.set('key1', 'value1', 1000);
      cacheService.set('key2', 'value2', 2000);
      
      jest.advanceTimersByTime(1500);
      
      expect(cacheService.get('key1')).toBeNull();
      expect(cacheService.get('key2')).toBe('value2');
    });
  });

  describe('cache management', () => {
    it('should check for existence', () => {
      cacheService.set('test-key', 'test-value');
      
      expect(cacheService.has('test-key')).toBe(true);
      expect(cacheService.has('non-existent')).toBe(false);
    });

    it('should delete specific items', () => {
      cacheService.set('key1', 'value1');
      cacheService.set('key2', 'value2');
      
      cacheService.delete('key1');
      
      expect(cacheService.get('key1')).toBeNull();
      expect(cacheService.get('key2')).toBe('value2');
    });

    it('should clear all items', () => {
      cacheService.set('key1', 'value1');
      cacheService.set('key2', 'value2');
      
      cacheService.clear();
      
      expect(cacheService.get('key1')).toBeNull();
      expect(cacheService.get('key2')).toBeNull();
    });
  });
});