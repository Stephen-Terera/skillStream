import { realtimeService } from '../realtimeService';
import { io } from 'socket.io-client';
import { store } from '../../store/store';

jest.mock('socket.io-client');
jest.mock('../../store/store');

describe('RealtimeService', () => {
  let mockSocket: any;

  beforeEach(() => {
    mockSocket = {
      connected: false,
      on: jest.fn(),
      emit: jest.fn(),
      disconnect: jest.fn(),
    };
    (io as jest.Mock).mockReturnValue(mockSocket);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('connect', () => {
    it('should establish connection with correct config', () => {
      realtimeService.connect('test-token');

      expect(io).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          auth: { token: 'test-token' },
          reconnection: true,
        })
      );
    });

    it('should set up event handlers', () => {
      realtimeService.connect('test-token');

      expect(mockSocket.on).toHaveBeenCalledWith('connect', expect.any(Function));
      expect(mockSocket.on).toHaveBeenCalledWith('disconnect', expect.any(Function));
      expect(mockSocket.on).toHaveBeenCalledWith('chat:message', expect.any(Function));
      expect(mockSocket.on).toHaveBeenCalledWith('study-group:update', expect.any(Function));
    });
  });

  describe('event handling', () => {
    it('should dispatch actions on events', () => {
      realtimeService.connect('test-token');

      // Get the chat message handler
      const messageHandler = mockSocket.on.mock.calls.find(
        call => call[0] === 'chat:message'
      )[1];

      // Simulate receiving a message
      messageHandler({ id: '1', content: 'test' });

      expect(store.dispatch).toHaveBeenCalledWith(
        expect.objectContaining({
          type: expect.any(String),
          payload: expect.objectContaining({
            id: '1',
            content: 'test'
          })
        })
      );
    });
  });

  describe('room management', () => {
    it('should join and leave rooms', () => {
      realtimeService.connect('test-token');
      
      realtimeService.joinRoom('room-1');
      expect(mockSocket.emit).toHaveBeenCalledWith('room:join', { roomId: 'room-1' });

      realtimeService.leaveRoom('room-1');
      expect(mockSocket.emit).toHaveBeenCalledWith('room:leave', { roomId: 'room-1' });
    });
  });
});