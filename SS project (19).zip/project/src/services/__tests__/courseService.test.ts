import { courseService } from '../courseService';
import { api } from '../api';

jest.mock('../api');

describe('courseService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getCourses', () => {
    it('should fetch courses with filters', async () => {
      const mockCourses = [{ id: '1', title: 'Test Course' }];
      (api.get as jest.Mock).mockResolvedValue(mockCourses);

      const filters = { category: 'web' };
      const result = await courseService.getCourses(filters);

      expect(result).toEqual(mockCourses);
      expect(api.get).toHaveBeenCalledWith('/courses', { params: filters });
    });
  });

  describe('enrollInCourse', () => {
    it('should enroll user in course', async () => {
      await courseService.enrollInCourse('course-123');

      expect(api.post).toHaveBeenCalledWith('/courses/course-123/enroll');
    });

    it('should handle enrollment errors', async () => {
      const error = new Error('Enrollment failed');
      (api.post as jest.Mock).mockRejectedValue(error);

      await expect(courseService.enrollInCourse('course-123')).rejects.toThrow('Enrollment failed');
    });
  });

  describe('getCourseProgress', () => {
    it('should fetch course progress', async () => {
      const mockProgress = 75;
      (api.get as jest.Mock).mockResolvedValue(mockProgress);

      const result = await courseService.getCourseProgress('course-123');

      expect(result).toBe(mockProgress);
      expect(api.get).toHaveBeenCalledWith('/courses/course-123/progress');
    });
  });
});