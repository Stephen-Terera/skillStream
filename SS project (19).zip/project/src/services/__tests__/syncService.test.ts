import { syncService } from '../syncService';
import { api } from '../api';
import { offlineManager } from '../../utils/offline';

jest.mock('../api');
jest.mock('../../utils/offline');

describe('SyncService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('queueForSync', () => {
    it('should queue items and save to offline storage', async () => {
      const syncItem = {
        type: 'note',
        action: 'create',
        data: { title: 'Test Note' }
      };

      await syncService.queueForSync(syncItem);

      expect(offlineManager.saveOfflineData).toHaveBeenCalledWith(
        'sync_queue',
        expect.arrayContaining([
          expect.objectContaining({
            ...syncItem,
            id: expect.any(String),
            timestamp: expect.any(Number),
            retries: 0
          })
        ])
      );
    });
  });

  describe('sync', () => {
    it('should process queued items', async () => {
      const mockNote = { id: '1', title: 'Test Note' };
      (api.post as jest.Mock).mockResolvedValue(mockNote);

      await syncService.queueForSync({
        type: 'note',
        action: 'create',
        data: mockNote
      });

      await syncService.sync();

      expect(api.post).toHaveBeenCalledWith('/notes', mockNote);
    });

    it('should handle sync failures and retry', async () => {
      const mockNote = { id: '1', title: 'Test Note' };
      (api.post as jest.Mock)
        .mockRejectedValueOnce(new Error('Network error'))
        .mockResolvedValueOnce(mockNote);

      await syncService.queueForSync({
        type: 'note',
        action: 'create',
        data: mockNote
      });

      await syncService.sync();
      await syncService.sync();

      expect(api.post).toHaveBeenCalledTimes(2);
    });

    it('should move failed items to failed queue after max retries', async () => {
      const mockNote = { id: '1', title: 'Test Note' };
      (api.post as jest.Mock).mockRejectedValue(new Error('Network error'));

      await syncService.queueForSync({
        type: 'note',
        action: 'create',
        data: mockNote
      });

      // Simulate max retries
      for (let i = 0; i < 4; i++) {
        await syncService.sync();
      }

      expect(offlineManager.saveOfflineData).toHaveBeenCalledWith(
        'failed_sync_items',
        expect.arrayContaining([
          expect.objectContaining({
            type: 'note',
            action: 'create',
            data: mockNote,
            retries: 3
          })
        ])
      );
    });
  });
});