import { analyticsService } from '../analyticsService';
import { api } from '../api';

jest.mock('../api');

describe('AnalyticsService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('trackEvent', () => {
    it('should queue events and flush when batch size is reached', async () => {
      const events = Array.from({ length: 10 }, (_, i) => ({
        eventName: `event-${i}`,
        properties: { test: true }
      }));

      for (const event of events) {
        await analyticsService.trackEvent(event.eventName, event.properties);
      }

      expect(api.post).toHaveBeenCalledWith('/analytics/events', {
        events: expect.arrayContaining([
          expect.objectContaining({
            eventName: expect.any(String),
            properties: expect.any(Object),
            timestamp: expect.any(String)
          })
        ])
      });
    });

    it('should auto-flush events after interval', async () => {
      await analyticsService.trackEvent('test-event');
      
      jest.advanceTimersByTime(30000);

      expect(api.post).toHaveBeenCalled();
    });
  });

  describe('analytics endpoints', () => {
    it('should fetch study stats', async () => {
      const mockStats = { totalTime: 1000, completedCourses: 5 };
      (api.get as jest.Mock).mockResolvedValue(mockStats);

      const result = await analyticsService.getStudyStats('user-123');

      expect(result).toEqual(mockStats);
      expect(api.get).toHaveBeenCalledWith('/analytics/study-stats/user-123');
    });

    it('should fetch engagement metrics', async () => {
      const mockMetrics = { activeUsers: 100, averageRating: 4.5 };
      (api.get as jest.Mock).mockResolvedValue(mockMetrics);

      const result = await analyticsService.getEngagementMetrics('course-123');

      expect(result).toEqual(mockMetrics);
      expect(api.get).toHaveBeenCalledWith('/analytics/engagement/course-123');
    });
  });
});