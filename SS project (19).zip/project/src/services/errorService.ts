import { AxiosError } from 'axios';
import { analyticsService } from './analyticsService';

export class ErrorService {
  private static instance: ErrorService;
  private errorQueue: Error[] = [];
  private readonly maxQueueSize = 100;

  private constructor() {}

  static getInstance(): ErrorService {
    if (!ErrorService.instance) {
      ErrorService.instance = new ErrorService();
    }
    return ErrorService.instance;
  }

  async handleError(error: Error | AxiosError, context?: string): Promise<void> {
    const errorDetails = {
      message: error.message,
      stack: error.stack,
      context,
      timestamp: new Date().toISOString(),
    };

    // Track error for analytics
    await analyticsService.trackEvent('error_occurred', errorDetails);

    // Add to error queue
    this.addToQueue(error);

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('Error occurred:', errorDetails);
    }
  }

  private addToQueue(error: Error): void {
    this.errorQueue.push(error);
    if (this.errorQueue.length > this.maxQueueSize) {
      this.errorQueue.shift();
    }
  }

  getRecentErrors(): Error[] {
    return [...this.errorQueue];
  }

  clearErrors(): void {
    this.errorQueue = [];
  }
}

export const errorService = ErrorService.getInstance();