```typescript
import { api } from './api';
import { errorService } from './errorService';

export interface Question {
  id: string;
  type: 'multiple-choice' | 'essay' | 'coding';
  content: string;
  options?: string[];
  correctAnswer?: string | string[];
  points: number;
  tags?: string[];
}

export interface Assessment {
  id: string;
  title: string;
  description: string;
  questions: Question[];
  timeLimit?: number;
  passingScore: number;
  attempts: number;
}

export interface Submission {
  id: string;
  assessmentId: string;
  userId: string;
  answers: Record<string, any>;
  score?: number;
  feedback?: string;
  startTime: string;
  endTime?: string;
}

class AssessmentService {
  private static instance: AssessmentService;

  private constructor() {}

  static getInstance(): AssessmentService {
    if (!AssessmentService.instance) {
      AssessmentService.instance = new AssessmentService();
    }
    return AssessmentService.instance;
  }

  async createAssessment(assessment: Omit<Assessment, 'id'>): Promise<Assessment> {
    try {
      return await api.post('/assessments', assessment);
    } catch (error) {
      await errorService.handleError(error as Error, 'createAssessment');
      throw error;
    }
  }

  async startAssessment(assessmentId: string): Promise<Submission> {
    try {
      return await api.post(`/assessments/${assessmentId}/start`);
    } catch (error) {
      await errorService.handleError(error as Error, 'startAssessment');
      throw error;
    }
  }

  async submitAnswer(
    submissionId: string,
    questionId: string,
    answer: any
  ): Promise<void> {
    try {
      await api.post(`/submissions/${submissionId}/answers`, {
        questionId,
        answer
      });
    } catch (error) {
      await errorService.handleError(error as Error, 'submitAnswer');
      throw error;
    }
  }

  async finishAssessment(submissionId: string): Promise<Submission> {
    try {
      return await api.post(`/submissions/${submissionId}/finish`);
    } catch (error) {
      await errorService.handleError(error as Error, 'finishAssessment');
      throw error;
    }
  }

  async gradeSubmission(submissionId: string): Promise<Submission> {
    try {
      return await api.post(`/submissions/${submissionId}/grade`);
    } catch (error) {
      await errorService.handleError(error as Error, 'gradeSubmission');
      throw error;
    }
  }

  async provideFeedback(
    submissionId: string,
    feedback: string
  ): Promise<Submission> {
    try {
      return await api.post(`/submissions/${submissionId}/feedback`, { feedback });
    } catch (error) {
      await errorService.handleError(error as Error, 'provideFeedback');
      throw error;
    }
  }

  async exportToSCORM(assessmentId: string): Promise<string> {
    try {
      const { url } = await api.post(`/assessments/${assessmentId}/export/scorm`);
      return url;
    } catch (error) {
      await errorService.handleError(error as Error, 'exportToSCORM');
      throw error;
    }
  }

  async exportToXAPI(submissionId: string): Promise<any> {
    try {
      return await api.post(`/submissions/${submissionId}/export/xapi`);
    } catch (error) {
      await errorService.handleError(error as Error, 'exportToXAPI');
      throw error;
    }
  }
}

export const assessmentService = AssessmentService.getInstance();
```