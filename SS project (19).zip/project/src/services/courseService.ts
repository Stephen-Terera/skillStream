import { api } from './api';
import type { Course, Instructor } from '../types';

export const courseService = {
  async getCourses(filters?: Record<string, any>): Promise<Course[]> {
    return api.get('/courses', { params: filters });
  },

  async getCourseById(id: string): Promise<Course> {
    return api.get(`/courses/${id}`);
  },

  async enrollInCourse(courseId: string): Promise<void> {
    return api.post(`/courses/${courseId}/enroll`);
  },

  async getInstructors(filters?: Record<string, any>): Promise<Instructor[]> {
    return api.get('/instructors', { params: filters });
  },

  async getInstructorById(id: string): Promise<Instructor> {
    return api.get(`/instructors/${id}`);
  },

  async getCourseProgress(courseId: string): Promise<number> {
    return api.get(`/courses/${courseId}/progress`);
  },

  async updateCourseProgress(courseId: string, progress: number): Promise<void> {
    return api.post(`/courses/${courseId}/progress`, { progress });
  }
};