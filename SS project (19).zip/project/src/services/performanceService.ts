import { analyticsService } from './analyticsService';

export class PerformanceService {
  private static instance: PerformanceService;
  private metrics: Map<string, number[]> = new Map();
  private readonly maxSamples = 100;

  private constructor() {}

  static getInstance(): PerformanceService {
    if (!PerformanceService.instance) {
      PerformanceService.instance = new PerformanceService();
    }
    return PerformanceService.instance;
  }

  startMeasure(metricName: string): () => void {
    const startTime = performance.now();
    
    return () => {
      const duration = performance.now() - startTime;
      this.recordMetric(metricName, duration);
    };
  }

  private recordMetric(name: string, value: number): void {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }

    const values = this.metrics.get(name)!;
    values.push(value);

    if (values.length > this.maxSamples) {
      values.shift();
    }

    // Track significant performance issues
    if (value > 1000) { // 1 second threshold
      analyticsService.trackEvent('performance_issue', {
        metric: name,
        value,
        timestamp: new Date().toISOString()
      });
    }
  }

  getMetrics(name: string): {
    average: number;
    min: number;
    max: number;
    samples: number;
  } {
    const values = this.metrics.get(name) || [];
    if (values.length === 0) {
      return { average: 0, min: 0, max: 0, samples: 0 };
    }

    return {
      average: values.reduce((a, b) => a + b, 0) / values.length,
      min: Math.min(...values),
      max: Math.max(...values),
      samples: values.length
    };
  }

  clearMetrics(): void {
    this.metrics.clear();
  }
}

export const performanceService = PerformanceService.getInstance();