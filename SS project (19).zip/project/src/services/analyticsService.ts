import { api } from './api';

export interface AnalyticsEvent {
  eventName: string;
  properties: Record<string, any>;
  timestamp: string;
}

class AnalyticsService {
  private static instance: AnalyticsService;
  private eventQueue: AnalyticsEvent[] = [];
  private isProcessing = false;
  private batchSize = 10;
  private flushInterval = 30000; // 30 seconds

  private constructor() {
    this.setupAutoFlush();
  }

  static getInstance(): AnalyticsService {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  private setupAutoFlush(): void {
    setInterval(() => this.flush(), this.flushInterval);
  }

  async trackEvent(eventName: string, properties: Record<string, any> = {}): Promise<void> {
    const event: AnalyticsEvent = {
      eventName,
      properties,
      timestamp: new Date().toISOString(),
    };

    this.eventQueue.push(event);

    if (this.eventQueue.length >= this.batchSize) {
      await this.flush();
    }
  }

  private async flush(): Promise<void> {
    if (this.isProcessing || this.eventQueue.length === 0) return;

    try {
      this.isProcessing = true;
      const events = this.eventQueue.splice(0, this.batchSize);
      await api.post('/analytics/events', { events });
    } catch (error) {
      console.error('Error flushing analytics events:', error);
      // Put events back in queue
      this.eventQueue.unshift(...this.eventQueue);
    } finally {
      this.isProcessing = false;
    }
  }

  async getStudyStats(userId: string): Promise<any> {
    return api.get(`/analytics/study-stats/${userId}`);
  }

  async getEngagementMetrics(courseId: string): Promise<any> {
    return api.get(`/analytics/engagement/${courseId}`);
  }

  async getLearningProgress(userId: string): Promise<any> {
    return api.get(`/analytics/learning-progress/${userId}`);
  }
}

export const analyticsService = AnalyticsService.getInstance();