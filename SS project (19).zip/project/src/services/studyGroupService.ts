import { api } from './api';

export interface StudyGroup {
  id: string;
  name: string;
  description: string;
  courseId: string;
  members: string[];
  schedule: {
    startTime: string;
    endTime: string;
    recurrence: 'once' | 'daily' | 'weekly' | 'monthly';
  };
}

export const studyGroupService = {
  async getStudyGroups(filters?: Record<string, any>): Promise<StudyGroup[]> {
    return api.get('/study-groups', { params: filters });
  },

  async createStudyGroup(groupData: Partial<StudyGroup>): Promise<StudyGroup> {
    return api.post('/study-groups', groupData);
  },

  async joinStudyGroup(groupId: string): Promise<void> {
    return api.post(`/study-groups/${groupId}/join`);
  },

  async leaveStudyGroup(groupId: string): Promise<void> {
    return api.post(`/study-groups/${groupId}/leave`);
  },

  async updateStudyGroup(groupId: string, updates: Partial<StudyGroup>): Promise<StudyGroup> {
    return api.patch(`/study-groups/${groupId}`, updates);
  },

  async deleteStudyGroup(groupId: string): Promise<void> {
    return api.delete(`/study-groups/${groupId}`);
  }
};