import { api } from './api';

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
}

export const chatService = {
  async getMessages(conversationId: string): Promise<ChatMessage[]> {
    return api.get(`/chat/${conversationId}/messages`);
  },

  async sendMessage(conversationId: string, content: string): Promise<ChatMessage> {
    return api.post(`/chat/${conversationId}/messages`, { content });
  },

  async markAsRead(messageIds: string[]): Promise<void> {
    return api.post('/chat/messages/read', { messageIds });
  },

  async getConversations(): Promise<any[]> {
    return api.get('/chat/conversations');
  },

  async createConversation(participantId: string): Promise<any> {
    return api.post('/chat/conversations', { participantId });
  }
};