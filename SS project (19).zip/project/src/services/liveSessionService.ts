import { api } from './api';
import { realtimeService } from './realtimeService';
import { errorService } from './errorService';
import { performanceService } from './performanceService';

export interface Participant {
  id: string;
  name: string;
  role: 'host' | 'participant';
  video: boolean;
  audio: boolean;
  hand: boolean;
}

export interface WhiteboardObject {
  id: string;
  type: 'path' | 'text' | 'shape';
  data: any;
  createdBy: string;
  timestamp: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface Poll {
  id: string;
  question: string;
  options: PollOption[];
  createdBy: string;
  timestamp: string;
  isActive: boolean;
}

export interface BreakoutRoom {
  id: string;
  name: string;
  participants: Participant[];
  duration: number;
  startTime?: string;
}

class LiveSessionService {
  private static instance: LiveSessionService;
  private peerConnections: Map<string, RTCPeerConnection> = new Map();
  private localStream: MediaStream | null = null;
  private currentSession: string | null = null;

  private constructor() {}

  static getInstance(): LiveSessionService {
    if (!LiveSessionService.instance) {
      LiveSessionService.instance = new LiveSessionService();
    }
    return LiveSessionService.instance;
  }

  async startSession(sessionId: string): Promise<void> {
    try {
      const endMeasure = performanceService.startMeasure('session_start');
      
      this.currentSession = sessionId;
      await this.setupMediaStream();
      await this.joinSession(sessionId);
      
      endMeasure();
    } catch (error) {
      await errorService.handleError(error as Error, 'startSession');
      throw error;
    }
  }

  private async setupMediaStream(): Promise<void> {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
    } catch (error) {
      await errorService.handleError(error as Error, 'setupMediaStream');
      throw new Error('Failed to access media devices');
    }
  }

  private async joinSession(sessionId: string): Promise<void> {
    try {
      const { participants, iceServers } = await api.post(`/sessions/${sessionId}/join`);
      
      // Connect to each participant
      for (const participant of participants) {
        await this.connectToPeer(participant.id, iceServers);
      }

      // Join realtime room for session events
      realtimeService.joinRoom(sessionId);
    } catch (error) {
      await errorService.handleError(error as Error, 'joinSession');
      throw error;
    }
  }

  private async connectToPeer(peerId: string, iceServers: RTCIceServer[]): Promise<void> {
    const peerConnection = new RTCPeerConnection({ iceServers });
    this.peerConnections.set(peerId, peerConnection);

    // Add local tracks
    this.localStream?.getTracks().forEach(track => {
      this.localStream && peerConnection.addTrack(track, this.localStream);
    });

    // Handle ICE candidates
    peerConnection.onicecandidate = event => {
      if (event.candidate) {
        realtimeService.sendMessage(this.currentSession!, {
          type: 'ice-candidate',
          candidate: event.candidate,
          peerId
        });
      }
    };

    // Handle incoming tracks
    peerConnection.ontrack = event => {
      // Dispatch event to update UI with remote stream
      window.dispatchEvent(new CustomEvent('remote-stream', {
        detail: { peerId, stream: event.streams[0] }
      }));
    };
  }

  // Whiteboard methods
  async addWhiteboardObject(object: Omit<WhiteboardObject, 'id' | 'timestamp'>): Promise<void> {
    try {
      const response = await api.post(`/sessions/${this.currentSession}/whiteboard`, object);
      realtimeService.sendMessage(this.currentSession!, {
        type: 'whiteboard-update',
        object: response.data
      });
    } catch (error) {
      await errorService.handleError(error as Error, 'addWhiteboardObject');
      throw error;
    }
  }

  // Poll methods
  async createPoll(question: string, options: string[]): Promise<Poll> {
    try {
      const poll = await api.post(`/sessions/${this.currentSession}/polls`, {
        question,
        options: options.map(text => ({ text, votes: 0 }))
      });

      realtimeService.sendMessage(this.currentSession!, {
        type: 'poll-created',
        poll
      });

      return poll;
    } catch (error) {
      await errorService.handleError(error as Error, 'createPoll');
      throw error;
    }
  }

  async votePoll(pollId: string, optionId: string): Promise<void> {
    try {
      await api.post(`/sessions/${this.currentSession}/polls/${pollId}/vote`, {
        optionId
      });
    } catch (error) {
      await errorService.handleError(error as Error, 'votePoll');
      throw error;
    }
  }

  // Breakout room methods
  async createBreakoutRooms(count: number, duration: number): Promise<BreakoutRoom[]> {
    try {
      const rooms = await api.post(`/sessions/${this.currentSession}/breakout-rooms`, {
        count,
        duration
      });

      realtimeService.sendMessage(this.currentSession!, {
        type: 'breakout-rooms-created',
        rooms
      });

      return rooms;
    } catch (error) {
      await errorService.handleError(error as Error, 'createBreakoutRooms');
      throw error;
    }
  }

  async joinBreakoutRoom(roomId: string): Promise<void> {
    try {
      await api.post(`/sessions/${this.currentSession}/breakout-rooms/${roomId}/join`);
      realtimeService.joinRoom(roomId);
    } catch (error) {
      await errorService.handleError(error as Error, 'joinBreakoutRoom');
      throw error;
    }
  }

  async endSession(): Promise<void> {
    try {
      if (!this.currentSession) return;

      // Close all peer connections
      this.peerConnections.forEach(connection => {
        connection.close();
      });
      this.peerConnections.clear();

      // Stop local stream
      this.localStream?.getTracks().forEach(track => track.stop());
      this.localStream = null;

      // Leave session
      await api.post(`/sessions/${this.currentSession}/leave`);
      realtimeService.leaveRoom(this.currentSession);
      this.currentSession = null;
    } catch (error) {
      await errorService.handleError(error as Error, 'endSession');
      throw error;
    }
  }
}

export const liveSessionService = LiveSessionService.getInstance();