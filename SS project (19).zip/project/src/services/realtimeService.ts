import { io, Socket } from 'socket.io-client';
import { store } from '../store/store';
import { addMessage } from '../store/slices/chatSlice';
import { updateStudyGroup } from '../store/slices/studyGroupsSlice';
import { updateCourseProgress } from '../store/slices/coursesSlice';

class RealtimeService {
  private static instance: RealtimeService;
  private socket: Socket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  private constructor() {}

  static getInstance(): RealtimeService {
    if (!RealtimeService.instance) {
      RealtimeService.instance = new RealtimeService();
    }
    return RealtimeService.instance;
  }

  connect(token: string): void {
    if (this.socket?.connected) return;

    this.socket = io(import.meta.env.VITE_WS_URL || 'wss://api.skillstream.com', {
      auth: { token },
      reconnection: true,
      reconnectionAttempts: this.maxReconnectAttempts,
      reconnectionDelay: 1000,
    });

    this.setupEventHandlers();
  }

  private setupEventHandlers(): void {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('Connected to realtime server');
      this.reconnectAttempts = 0;
    });

    this.socket.on('disconnect', (reason) => {
      console.log('Disconnected from realtime server:', reason);
    });

    this.socket.on('chat:message', (message) => {
      store.dispatch(addMessage(message));
    });

    this.socket.on('study-group:update', (group) => {
      store.dispatch(updateStudyGroup(group));
    });

    this.socket.on('course:progress', (progress) => {
      store.dispatch(updateCourseProgress(progress));
    });

    this.socket.on('connect_error', (error) => {
      console.error('Connection error:', error);
      this.reconnectAttempts++;
      
      if (this.reconnectAttempts >= this.maxReconnectAttempts) {
        this.socket?.disconnect();
      }
    });
  }

  joinRoom(roomId: string): void {
    this.socket?.emit('room:join', { roomId });
  }

  leaveRoom(roomId: string): void {
    this.socket?.emit('room:leave', { roomId });
  }

  sendMessage(roomId: string, message: any): void {
    this.socket?.emit('chat:message', { roomId, message });
  }

  disconnect(): void {
    this.socket?.disconnect();
    this.socket = null;
  }
}

export const realtimeService = RealtimeService.getInstance();