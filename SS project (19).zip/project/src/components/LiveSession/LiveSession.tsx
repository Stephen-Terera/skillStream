```tsx
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Video, Mic, MicOff, VideoOff, Hand, Share2 } from 'lucide-react';
import { liveSessionService, type Participant } from '../../services/liveSessionService';
import Whiteboard from './Whiteboard';
import PollManager from './PollManager';
import BreakoutRooms from './BreakoutRooms';
import ParticipantGrid from './ParticipantGrid';

interface Props {
  sessionId: string;
  onEnd?: () => void;
}

export default function LiveSession({ sessionId, onEnd }: Props) {
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [activeView, setActiveView] = useState<'grid' | 'whiteboard'>('grid');
  const localVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const startLiveSession = async () => {
      try {
        await liveSessionService.startSession(sessionId);
        
        // Set up local video
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = liveSessionService.getLocalStream();
        }

        // Listen for participant updates
        window.addEventListener('participant-update', handleParticipantUpdate);
        window.addEventListener('remote-stream', handleRemoteStream);
      } catch (error) {
        console.error('Failed to start session:', error);
      }
    };

    startLiveSession();

    return () => {
      window.removeEventListener('participant-update', handleParticipantUpdate);
      window.removeEventListener('remote-stream', handleRemoteStream);
      liveSessionService.endSession();
    };
  }, [sessionId]);

  const handleParticipantUpdate = (event: CustomEvent) => {
    setParticipants(event.detail.participants);
  };

  const handleRemoteStream = (event: CustomEvent) => {
    const { peerId, stream } = event.detail;
    // Update participant video element
    const videoElement = document.getElementById(`video-${peerId}`) as HTMLVideoElement;
    if (videoElement) {
      videoElement.srcObject = stream;
    }
  };

  const toggleAudio = () => {
    liveSessionService.toggleAudio();
    setIsAudioEnabled(!isAudioEnabled);
  };

  const toggleVideo = () => {
    liveSessionService.toggleVideo();
    setIsVideoEnabled(!isVideoEnabled);
  };

  const toggleHand = () => {
    liveSessionService.toggleHand();
    setIsHandRaised(!isHandRaised);
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="bg-[#0B1026] p-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-bold">Live Session</h1>
          <div className="flex items-center space-x-2">
            <Users size={20} />
            <span>{participants.length}</span>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setActiveView(activeView === 'grid' ? 'whiteboard' : 'grid')}
            className="cosmic-button"
          >
            {activeView === 'grid' ? 'Show Whiteboard' : 'Show Participants'}
          </button>
          <button onClick={onEnd} className="cosmic-button bg-red-500 hover:bg-red-600">
            End Session
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        <AnimatePresence mode="wait">
          {activeView === 'grid' ? (
            <motion.div
              key="grid"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex-1"
            >
              <ParticipantGrid
                participants={participants}
                localVideoRef={localVideoRef}
              />
            </motion.div>
          ) : (
            <motion.div
              key="whiteboard"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1"
            >
              <Whiteboard sessionId={sessionId} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Side Panel */}
        <div className="w-80 bg-[#0B1026] p-4 flex flex-col">
          <PollManager sessionId={sessionId} />
          <BreakoutRooms sessionId={sessionId} />
        </div>
      </div>

      {/* Controls */}
      <div className="bg-[#0B1026] p-4 flex items-center justify-center space-x-4">
        <button
          onClick={toggleAudio}
          className={`cosmic-button ${!isAudioEnabled && 'bg-red-500 hover:bg-red-600'}`}
        >
          {isAudioEnabled ? <Mic size={20} /> : <MicOff size={20} />}
        </button>
        <button
          onClick={toggleVideo}
          className={`cosmic-button ${!isVideoEnabled && 'bg-red-500 hover:bg-red-600'}`}
        >
          {isVideoEnabled ? <Video size={20} /> : <VideoOff size={20} />}
        </button>
        <button
          onClick={toggleHand}
          className={`cosmic-button ${isHandRaised && 'bg-yellow-500 hover:bg-yellow-600'}`}
        >
          <Hand size={20} />
        </button>
        <button className="cosmic-button">
          <Share2 size={20} />
        </button>
      </div>
    </div>
  );
}
```