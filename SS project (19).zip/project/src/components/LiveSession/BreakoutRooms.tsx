```tsx
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Clock, Plus, X } from 'lucide-react';
import { liveSessionService, type BreakoutRoom } from '../../services/liveSessionService';

interface Props {
  sessionId: string;
}

export default function BreakoutRooms({ sessionId }: Props) {
  const [rooms, setRooms] = useState<BreakoutRoom[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [roomCount, setRoomCount] = useState(2);
  const [duration, setDuration] = useState(15);

  const createRooms = async () => {
    try {
      const newRooms = await liveSessionService.createBreakoutRooms(
        roomCount,
        duration * 60 // Convert minutes to seconds
      );
      setRooms(newRooms);
      setIsCreating(false);
    } catch (error) {
      console.error('Failed to create breakout rooms:', error);
    }
  };

  const joinRoom = async (roomId: string) => {
    try {
      await liveSessionService.joinBreakoutRoom(roomId);
    } catch (error) {
      console.error('Failed to join breakout room:', error);
    }
  };

  const getRemainingTime = (startTime: string, duration: number): string => {
    const endTime = new Date(startTime).getTime() + duration * 1000;
    const remaining = Math.max(0, endTime - Date.now());
    const minutes = Math.floor(remaining / 60000);
    const seconds = Math.floor((remaining % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="mt-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Breakout Rooms</h3>
        <button
          onClick={() => setIsCreating(true)}
          className="cosmic-button"
        >
          <Plus size={20} />
        </button>
      </div>

      <AnimatePresence>
        {isCreating && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="cosmic-card"
          >
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Number of Rooms
                </label>
                <input
                  type="number"
                  min={2}
                  max={10}
                  value={roomCount}
                  onChange={(e) => setRoomCount(parseInt(e.target.value))}
                  className="cosmic-input w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Duration (minutes)
                </label>
                <input
                  type="number"
                  min={5}
                  max={60}
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="cosmic-input w-full"
                />
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setIsCreating(false)}
                  className="cosmic-button"
                >
                  Cancel
                </button>
                <button
                  onClick={createRooms}
                  className="cosmic-button"
                >
                  Create Rooms
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {rooms.map((room) => (
          <motion.div
            key={room.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="cosmic-card"
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold">{room.name}</h4>
              {room.startTime && (
                <div className="flex items-center text-sm">
                  <Clock size={16} className="mr-1" />
                  {getRemainingTime(room.startTime, room.duration)}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center text-sm text-gray-400">
                <Users size={16} className="mr-1" />
                {room.participants.length} participants
              </div>
            </div>

            <button
              onClick={() => joinRoom(room.id)}
              className="cosmic-button w-full justify-center"
            >
              Join Room
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
```