```tsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BarChart2, Plus } from 'lucide-react';
import { liveSessionService, type Poll } from '../../services/liveSessionService';

interface Props {
  sessionId: string;
}

export default function PollManager({ sessionId }: Props) {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);

  const createPoll = async () => {
    try {
      const poll = await liveSessionService.createPoll(
        question,
        options.filter(Boolean)
      );
      setPolls([...polls, poll]);
      setIsCreating(false);
      setQuestion('');
      setOptions(['', '']);
    } catch (error) {
      console.error('Failed to create poll:', error);
    }
  };

  const vote = async (pollId: string, optionId: string) => {
    try {
      await liveSessionService.votePoll(pollId, optionId);
    } catch (error) {
      console.error('Failed to vote:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Polls</h3>
        <button
          onClick={() => setIsCreating(true)}
          className="cosmic-button"
        >
          <Plus size={20} />
        </button>
      </div>

      <AnimatePresence>
        {isCreating && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="cosmic-card"
          >
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question"
              className="cosmic-input w-full mb-4"
            />

            {options.map((option, index) => (
              <input
                key={index}
                type="text"
                value={option}
                onChange={(e) => {
                  const newOptions = [...options];
                  newOptions[index] = e.target.value;
                  setOptions(newOptions);
                }}
                placeholder={`Option ${index + 1}`}
                className="cosmic-input w-full mb-2"
              />
            ))}

            <div className="flex justify-end space-x-2 mt-4">
              <button
                onClick={() => setOptions([...options, ''])}
                className="cosmic-button"
              >
                Add Option
              </button>
              <button
                onClick={createPoll}
                disabled={!question || options.filter(Boolean).length < 2}
                className="cosmic-button"
              >
                Create Poll
              </button>
            </div>
          </motion.div>
        )}

        {polls.map((poll) => (
          <motion.div
            key={poll.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="cosmic-card"
          >
            <h4 className="font-semibold mb-2">{poll.question}</h4>
            <div className="space-y-2">
              {poll.options.map((option) => {
                const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
                const percentage = totalVotes > 0
                  ? Math.round((option.votes / totalVotes) * 100)
                  : 0;

                return (
                  <div key={option.id} className="relative">
                    <button
                      onClick={() => vote(poll.id, option.id)}
                      className="w-full text-left p-2 rounded-lg bg-blue-500/10 hover:bg-blue-500/20"
                    >
                      <div className="absolute inset-0 bg-blue-500/20 rounded-lg"
                        style={{ width: `${percentage}%` }}
                      />
                      <span className="relative z-10 flex justify-between">
                        <span>{option.text}</span>
                        <span>{percentage}%</span>
                      </span>
                    </button>
                  </div>
                );
              })}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
```