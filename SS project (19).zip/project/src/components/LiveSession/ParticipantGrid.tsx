```tsx
import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Mic, MicOff, Video, VideoOff, Crown } from 'lucide-react';
import type { Participant } from '../../services/liveSessionService';

interface Props {
  participants: Participant[];
  localVideoRef: React.RefObject<HTMLVideoElement>;
}

export default function ParticipantGrid({ participants, localVideoRef }: Props) {
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Optimize grid layout based on participant count
    const grid = gridRef.current;
    if (!grid) return;

    const count = participants.length + 1; // Include local video
    const aspectRatio = 16 / 9;
    const screenRatio = grid.offsetWidth / grid.offsetHeight;
    
    let cols = Math.ceil(Math.sqrt(count * screenRatio / aspectRatio));
    let rows = Math.ceil(count / cols);
    
    // Ensure we have enough grid spots
    if (cols * rows < count) {
      cols = Math.ceil(count / rows);
    }

    grid.style.setProperty('--grid-cols', cols.toString());
    grid.style.setProperty('--grid-rows', rows.toString());
  }, [participants.length]);

  const getGridSpan = (isHost: boolean): string => {
    const totalParticipants = participants.length + 1;
    if (isHost && totalParticipants <= 4) {
      return 'col-span-2 row-span-2';
    }
    return '';
  };

  return (
    <div
      ref={gridRef}
      className="h-full p-4 grid gap-4"
      style={{
        gridTemplateColumns: 'repeat(var(--grid-cols), 1fr)',
        gridTemplateRows: 'repeat(var(--grid-rows), 1fr)',
      }}
    >
      {/* Local Video */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className={`relative bg-blue-500/10 rounded-lg overflow-hidden ${getGridSpan(true)}`}
      >
        <video
          ref={localVideoRef}
          autoPlay
          muted
          playsInline
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/50 to-transparent">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">You (Host)</span>
            <div className="flex items-center space-x-2">
              <Crown className="w-4 h-4 text-yellow-400" />
            </div>
          </div>
        </div>
      </motion.div>

      {/* Remote Participants */}
      {participants.map((participant) => (
        <motion.div
          key={participant.id}
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className={`relative bg-blue-500/10 rounded-lg overflow-hidden ${
            getGridSpan(participant.role === 'host')
          }`}
        >
          <video
            id={`video-${participant.id}`}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/50 to-transparent">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{participant.name}</span>
              <div className="flex items-center space-x-2">
                {participant.role === 'host' && (
                  <Crown className="w-4 h-4 text-yellow-400" />
                )}
                {participant.audio ? (
                  <Mic className="w-4 h-4" />
                ) : (
                  <MicOff className="w-4 h-4 text-red-400" />
                )}
                {participant.video ? (
                  <Video className="w-4 h-4" />
                ) : (
                  <VideoOff className="w-4 h-4 text-red-400" />
                )}
                {participant.hand && (
                  <span className="text-yellow-400">✋</span>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
```