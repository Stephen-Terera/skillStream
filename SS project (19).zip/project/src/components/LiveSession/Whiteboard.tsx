```tsx
import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Pencil, Type, Square, Circle, Eraser, Undo, Redo } from 'lucide-react';
import { liveSessionService } from '../../services/liveSessionService';

interface Props {
  sessionId: string;
}

type Tool = 'pencil' | 'text' | 'rectangle' | 'circle' | 'eraser';

export default function Whiteboard({ sessionId }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedTool, setSelectedTool] = useState<Tool>('pencil');
  const [isDrawing, setIsDrawing] = useState(false);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set up canvas
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;

    // Save initial state
    saveState();
  }, []);

  const saveState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory(prev => [...prev.slice(0, historyIndex + 1), imageData]);
    setHistoryIndex(prev => prev + 1);
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    switch (selectedTool) {
      case 'pencil':
        ctx.lineTo(x, y);
        ctx.stroke();
        break;
      case 'rectangle':
        // Implementation for rectangle
        break;
      case 'circle':
        // Implementation for circle
        break;
      case 'eraser':
        ctx.strokeStyle = '#fff';
        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.strokeStyle = '#000';
        break;
    }
  };

  const stopDrawing = () => {
    if (!isDrawing) return;

    setIsDrawing(false);
    saveState();

    // Send whiteboard update
    const canvas = canvasRef.current;
    if (!canvas) return;

    liveSessionService.addWhiteboardObject({
      type: 'path',
      data: canvas.toDataURL(),
      createdBy: 'current-user'
    });
  };

  const undo = () => {
    if (historyIndex <= 0) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setHistoryIndex(prev => prev - 1);
    ctx.putImageData(history[historyIndex - 1], 0, 0);
  };

  const redo = () => {
    if (historyIndex >= history.length - 1) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setHistoryIndex(prev => prev + 1);
    ctx.putImageData(history[historyIndex + 1], 0, 0);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="p-4 flex items-center space-x-4">
        <button
          onClick={() => setSelectedTool('pencil')}
          className={`cosmic-button ${selectedTool === 'pencil' && 'bg-blue-500'}`}
        >
          <Pencil size={20} />
        </button>
        <button
          onClick={() => setSelectedTool('text')}
          className={`cosmic-button ${selectedTool === 'text' && 'bg-blue-500'}`}
        >
          <Type size={20} />
        </button>
        <button
          onClick={() => setSelectedTool('rectangle')}
          className={`cosmic-button ${selectedTool === 'rectangle' && 'bg-blue-500'}`}
        >
          <Square size={20} />
        </button>
        <button
          onClick={() => setSelectedTool('circle')}
          className={`cosmic-button ${selectedTool === 'circle' && 'bg-blue-500'}`}
        >
          <Circle size={20} />
        </button>
        <button
          onClick={() => setSelectedTool('eraser')}
          className={`cosmic-button ${selectedTool === 'eraser' && 'bg-blue-500'}`}
        >
          <Eraser size={20} />
        </button>
        <div className="border-l border-gray-600 h-6 mx-2" />
        <button
          onClick={undo}
          disabled={historyIndex <= 0}
          className="cosmic-button disabled:opacity-50"
        >
          <Undo size={20} />
        </button>
        <button
          onClick={redo}
          disabled={historyIndex >= history.length - 1}
          className="cosmic-button disabled:opacity-50"
        >
          <Redo size={20} />
        </button>
      </div>

      {/* Canvas */}
      <motion.canvas
        ref={canvasRef}
        className="flex-1 bg-white"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      />
    </div>
  );
}
```