import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import { 
  Home, BookOpen, Users, MessageSquare, Layout, Map, 
  BookMarked, Settings, LogIn 
} from 'lucide-react';

// Import screens
import HomePage from '../pages/HomePage';
import CoursesPage from '../pages/CoursesPage';
import TutorsPage from '../pages/TutorsPage';
import ChatPage from '../pages/ChatPage';
import DashboardPage from '../pages/DashboardPage';
import SkillMapPage from '../pages/SkillMapPage';
import StudyGroupsPage from '../pages/StudyGroupsPage';
import NotesPage from '../pages/NotesPage';
import PreferencesPage from '../pages/PreferencesPage';
import AuthPage from '../pages/AuthPage';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#0B1026',
          borderTopColor: 'rgba(59, 130, 246, 0.2)',
        },
        tabBarActiveTintColor: '#3b82f6',
        tabBarInactiveTintColor: '#a0aec0',
      }}
    >
      <Tab.Screen 
        name="Home" 
        component={HomePage}
        options={{
          tabBarIcon: ({ color }) => <Home size={24} color={color} />,
        }}
      />
      <Tab.Screen 
        name="Courses" 
        component={CoursesPage}
        options={{
          tabBarIcon: ({ color }) => <BookOpen size={24} color={color} />,
        }}
      />
      <Tab.Screen 
        name="Chat" 
        component={ChatPage}
        options={{
          tabBarIcon: ({ color }) => <MessageSquare size={24} color={color} />,
        }}
      />
      <Tab.Screen 
        name="Dashboard" 
        component={DashboardPage}
        options={{
          tabBarIcon: ({ color }) => <Layout size={24} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}

function DrawerContent() {
  return (
    <Drawer.Navigator
      screenOptions={{
        drawerStyle: {
          backgroundColor: '#0B1026',
          width: 280,
        },
        drawerLabelStyle: {
          color: '#ffffff',
        },
        drawerActiveBackgroundColor: 'rgba(59, 130, 246, 0.2)',
        drawerActiveTintColor: '#3b82f6',
      }}
    >
      <Drawer.Screen 
        name="MainTabs" 
        component={MainTabs}
        options={{ drawerLabel: 'Home' }}
      />
      <Drawer.Screen 
        name="SkillMap" 
        component={SkillMapPage}
        options={{
          drawerIcon: ({ color }) => <Map size={24} color={color} />,
        }}
      />
      <Drawer.Screen 
        name="StudyGroups" 
        component={StudyGroupsPage}
        options={{
          drawerIcon: ({ color }) => <Users size={24} color={color} />,
        }}
      />
      <Drawer.Screen 
        name="Notes" 
        component={NotesPage}
        options={{
          drawerIcon: ({ color }) => <BookMarked size={24} color={color} />,
        }}
      />
      <Drawer.Screen 
        name="Preferences" 
        component={PreferencesPage}
        options={{
          drawerIcon: ({ color }) => <Settings size={24} color={color} />,
        }}
      />
    </Drawer.Navigator>
  );
}

export function MainNavigator() {
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!isAuthenticated ? (
          <Stack.Screen 
            name="Auth" 
            component={AuthPage}
            options={{
              headerShown: true,
              headerTitle: 'Sign In',
              headerStyle: {
                backgroundColor: '#0B1026',
              },
              headerTintColor: '#ffffff',
            }}
          />
        ) : (
          <Stack.Screen name="Main" component={DrawerContent} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}