```tsx
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, AlertCircle } from 'lucide-react';
import { assessmentService, type Assessment, type Question } from '../../services/assessmentService';

interface Props {
  assessmentId: string;
  onComplete?: (score: number) => void;
}

export default function AssessmentEngine({ assessmentId, onComplete }: Props) {
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [submissionId, setSubmissionId] = useState<string | null>(null);

  useEffect(() => {
    loadAssessment();
  }, [assessmentId]);

  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => (prev ?? 0) - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const loadAssessment = async () => {
    try {
      // Start assessment session
      const submission = await assessmentService.startAssessment(assessmentId);
      setSubmissionId(submission.id);
      
      // Set time limit if specified
      if (assessment?.timeLimit) {
        setTimeLeft(assessment.timeLimit * 60);
      }
    } catch (error) {
      console.error('Failed to load assessment:', error);
    }
  };

  const handleAnswer = async (questionId: string, answer: any) => {
    try {
      await assessmentService.submitAnswer(submissionId!, questionId, answer);
      setAnswers(prev => ({ ...prev, [questionId]: answer }));
    } catch (error) {
      console.error('Failed to submit answer:', error);
    }
  };

  const submitAssessment = async () => {
    try {
      const submission = await assessmentService.finishAssessment(submissionId!);
      const gradedSubmission = await assessmentService.gradeSubmission(submissionId!);
      onComplete?.(gradedSubmission.score ?? 0);
    } catch (error) {
      console.error('Failed to submit assessment:', error);
    }
  };

  const renderQuestion = (question: Question) => {
    switch (question.type) {
      case 'multiple-choice':
        return (
          <div className="space-y-4">
            {question.options?.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(question.id, option)}
                className={`w-full p-4 text-left rounded-lg transition-colors ${
                  answers[question.id] === option
                    ? 'bg-blue-500 text-white'
                    : 'bg-blue-500/10 hover:bg-blue-500/20'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        );

      case 'essay':
        return (
          <textarea
            value={answers[question.id] || ''}
            onChange={(e) => handleAnswer(question.id, e.target.value)}
            className="cosmic-input w-full h-48 resize-none"
            placeholder="Enter your answer..."
          />
        );

      case 'coding':
        return (
          <div className="space-y-4">
            <textarea
              value={answers[question.id] || ''}
              onChange={(e) => handleAnswer(question.id, e.target.value)}
              className="cosmic-input w-full h-48 font-mono"
              placeholder="Write your code here..."
            />
            <button
              onClick={() => {/* Run code */}}
              className="cosmic-button"
            >
              Run Code
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  if (!assessment) return null;

  const question = assessment.questions[currentQuestion];

  return (
    <div className="max-w-3xl mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">{assessment.title}</h1>
        {timeLeft !== null && (
          <div className="flex items-center space-x-2 text-lg">
            <Clock className="text-yellow-400" />
            <span>
              {Math.floor(timeLeft / 60)}:
              {(timeLeft % 60).toString().padStart(2, '0')}
            </span>
          </div>
        )}
      </div>

      {/* Progress */}
      <div className="mb-8">
        <div className="flex justify-between text-sm mb-2">
          <span>Question {currentQuestion + 1} of {assessment.questions.length}</span>
          <span>{Math.round((currentQuestion + 1) / assessment.questions.length * 100)}%</span>
        </div>
        <div className="h-2 bg-blue-500/20 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-blue-500"
            initial={{ width: 0 }}
            animate={{
              width: `${((currentQuestion + 1) / assessment.questions.length) * 100}%`
            }}
          />
        </div>
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={question.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="space-y-6"
        >
          <div className="cosmic-card">
            <h2 className="text-xl font-semibold mb-4">{question.content}</h2>
            {renderQuestion(question)}
          </div>

          <div className="flex justify-between">
            <button
              onClick={() => setCurrentQuestion(prev => prev - 1)}
              disabled={currentQuestion === 0}
              className="cosmic-button disabled:opacity-50"
            >
              Previous
            </button>
            {currentQuestion < assessment.questions.length - 1 ? (
              <button
                onClick={() => setCurrentQuestion(prev => prev + 1)}
                disabled={!answers[question.id]}
                className="cosmic-button disabled:opacity-50"
              >
                Next
              </button>
            ) : (
              <button
                onClick={submitAssessment}
                disabled={!answers[question.id]}
                className="cosmic-button bg-green-500 hover:bg-green-600 disabled:opacity-50"
              >
                Submit Assessment
              </button>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Warning for unanswered questions */}
      {currentQuestion === assessment.questions.length - 1 && 
       Object.keys(answers).length < assessment.questions.length && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20"
        >
          <div className="flex items-center space-x-2 text-yellow-400">
            <AlertCircle />
            <span>
              You have {assessment.questions.length - Object.keys(answers).length} unanswered
              questions. Please review before submitting.
            </span>
          </div>
        </motion.div>
      )}
    </div>
  );
}
```