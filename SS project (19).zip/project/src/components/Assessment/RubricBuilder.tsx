```tsx
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save, AlertCircle } from 'lucide-react';

interface RubricCriterion {
  id: string;
  name: string;
  description: string;
  levels: {
    score: number;
    description: string;
  }[];
}

interface Props {
  initialRubric?: RubricCriterion[];
  onSave: (rubric: RubricCriterion[]) => void;
}

export default function RubricBuilder({ initialRubric = [], onSave }: Props) {
  const [criteria, setCriteria] = useState<RubricCriterion[]>(initialRubric);
  const [error, setError] = useState<string | null>(null);

  const addCriterion = () => {
    setCriteria([
      ...criteria,
      {
        id: Date.now().toString(),
        name: '',
        description: '',
        levels: [
          { score: 4, description: 'Excellent' },
          { score: 3, description: 'Good' },
          { score: 2, description: 'Fair' },
          { score: 1, description: 'Poor' }
        ]
      }
    ]);
  };

  const updateCriterion = (id: string, updates: Partial<RubricCriterion>) => {
    setCriteria(prev =>
      prev.map(criterion =>
        criterion.id === id ? { ...criterion, ...updates } : criterion
      )
    );
  };

  const deleteCriterion = (id: string) => {
    setCriteria(prev => prev.filter(criterion => criterion.id !== id));
  };

  const addLevel = (criterionId: string) => {
    setCriteria(prev =>
      prev.map(criterion =>
        criterion.id === criterionId
          ? {
              ...criterion,
              levels: [
                ...criterion.levels,
                { score: 0, description: '' }
              ]
            }
          : criterion
      )
    );
  };

  const updateLevel = (
    criterionId: string,
    index: number,
    updates: Partial<RubricCriterion['levels'][0]>
  ) => {
    setCriteria(prev =>
      prev.map(criterion =>
        criterion.id === criterionId
          ? {
              ...criterion,
              levels: criterion.levels.map((level, i) =>
                i === index ? { ...level, ...updates } : level
              )
            }
          : criterion
      )
    );
  };

  const deleteLevel = (criterionId: string, index: number) => {
    setCriteria(prev =>
      prev.map(criterion =>
        criterion.id === criterionId
          ? {
              ...criterion,
              levels: criterion.levels.filter((_, i) => i !== index)
            }
          : criterion
      )
    );
  };

  const handleSave = () => {
    // Validate rubric
    const isValid = criteria.every(criterion =>
      criterion.name &&
      criterion.description &&
      criterion.levels.length > 0 &&
      criterion.levels.every(level =>
        level.score >= 0 && level.description
      )
    );

    if (!isValid) {
      setError('Please fill in all required fields');
      return;
    }

    setError(null);
    onSave(criteria);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Rubric Builder</h2>
        <div className="flex space-x-4">
          <button
            onClick={addCriterion}
            className="cosmic-button"
          >
            <Plus size={20} />
            <span>Add Criterion</span>
          </button>
          <button
            onClick={handleSave}
            className="cosmic-button"
          >
            <Save size={20} />
            <span>Save Rubric</span>
          </button>
        </div>
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center space-x-2 text-red-400"
        >
          <AlertCircle size={20} />
          <span>{error}</span>
        </motion.div>
      )}

      <div className="space-y-6">
        {criteria.map((criterion) => (
          <motion.div
            key={criterion.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="cosmic-card"
          >
            {/* Criterion Header */}
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1 space-y-4 mr-4">
                <input
                  type="text"
                  value={criterion.name}
                  onChange={(e) => updateCriterion(criterion.id, { name: e.target.value })}
                  placeholder="Criterion Name"
                  className="cosmic-input w-full"
                />
                <textarea
                  value={criterion.description}
                  onChange={(e) => updateCriterion(criterion.id, { description: e.target.value })}
                  placeholder="Criterion Description"
                  className="cosmic-input w-full h-24 resize-none"
                />
              </div>
              <button
                onClick={() => deleteCriterion(criterion.id)}
                className="text-red-400 hover:text-red-300 transition-colors"
              >
                <Trash2 size={20} />
              </button>
            </div>

            {/* Performance Levels */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Performance Levels</h3>
                <button
                  onClick={() => addLevel(criterion.id)}
                  className="cosmic-button text-sm"
                >
                  <Plus size={16} />
                  <span>Add Level</span>
                </button>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {criterion.levels.map((level, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-start space-x-4"
                  >
                    <input
                      type="number"
                      value={level.score}
                      onChange={(e) => updateLevel(criterion.id, index, { score: Number(e.target.value) })}
                      min="0"
                      className="cosmic-input w-24"
                    />
                    <textarea
                      value={level.description}
                      onChange={(e) => updateLevel(criterion.id, index, { description: e.target.value })}
                      placeholder="Level Description"
                      className="cosmic-input flex-1 h-20 resize-none"
                    />
                    <button
                      onClick={() => deleteLevel(criterion.id, index)}
                      className="text-red-400 hover:text-red-300 transition-colors"
                    >
                      <Trash2 size={20} />
                    </button>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
```