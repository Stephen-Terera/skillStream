```tsx
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, MessageSquare } from 'lucide-react';
import { assessmentService, type Submission } from '../../services/assessmentService';

interface Props {
  submission: Submission;
  onGraded?: (submission: Submission) => void;
}

export default function GradingPanel({ submission, onGraded }: Props) {
  const [feedback, setFeedback] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitGrade = async () => {
    try {
      setIsSubmitting(true);
      const gradedSubmission = await assessmentService.provideFeedback(
        submission.id,
        feedback
      );
      onGraded?.(gradedSubmission);
    } catch (error) {
      console.error('Failed to submit grade:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="cosmic-card">
      <h2 className="text-xl font-bold mb-6">Grade Submission</h2>

      {/* Answers Review */}
      <div className="space-y-6 mb-8">
        {Object.entries(submission.answers).map(([questionId, answer]) => (
          <div key={questionId} className="cosmic-card">
            <div className="flex items-start justify-between mb-4">
              <h3 className="font-semibold">Question {questionId}</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {/* Mark correct */}}
                  className="p-2 rounded-full hover:bg-green-500/20"
                >
                  <Check className="text-green-400" />
                </button>
                <button
                  onClick={() => {/* Mark incorrect */}}
                  className="p-2 rounded-full hover:bg-red-500/20"
                >
                  <X className="text-red-400" />
                </button>
              </div>
            </div>

            <div className="mb-4">
              <p className="text-gray-400 mb-2">Student's Answer:</p>
              <div className="p-4 rounded-lg bg-blue-500/10">
                {typeof answer === 'string' ? (
                  <p>{answer}</p>
                ) : (
                  <pre className="font-mono">{JSON.stringify(answer, null, 2)}</pre>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Question Feedback
              </label>
              <textarea
                className="cosmic-input w-full h-24 resize-none"
                placeholder="Provide feedback for this answer..."
              />
            </div>
          </div>
        ))}
      </div>

      {/* Overall Feedback */}
      <div className="mb-6">
        <label className="block text-sm font-medium mb-2">
          Overall Feedback
        </label>
        <textarea
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          className="cosmic-input w-full h-32 resize-none"
          placeholder="Provide overall feedback for the submission..."
        />
      </div>

      {/* Actions */}
      <div className="flex justify-end space-x-4">
        <button
          onClick={submitGrade}
          disabled={isSubmitting || !feedback.trim()}
          className="cosmic-button disabled:opacity-50"
        >
          <MessageSquare className="w-4 h-4 mr-2" />
          Submit Feedback
        </button>
      </div>
    </div>
  );
}
```