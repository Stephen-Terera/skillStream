```tsx
import { render, fireEvent, waitFor } from '@testing-library/react';
import GradingPanel from '../GradingPanel';
import { assessmentService } from '../../../services/assessmentService';

jest.mock('../../../services/assessmentService');

describe('GradingPanel', () => {
  const mockSubmission = {
    id: 'sub123',
    assessmentId: 'ass123',
    userId: 'user123',
    answers: {
      'q1': 'Test answer 1',
      'q2': 'Test answer 2'
    },
    startTime: '2024-03-19T10:00:00Z'
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders all answers for review', () => {
    const { getByText } = render(
      <GradingPanel submission={mockSubmission} />
    );

    expect(getByText('Question q1')).toBeInTheDocument();
    expect(getByText('Question q2')).toBeInTheDocument();
    expect(getByText('Test answer 1')).toBeInTheDocument();
    expect(getByText('Test answer 2')).toBeInTheDocument();
  });

  it('submits feedback successfully', async () => {
    const onGraded = jest.fn();
    const mockGradedSubmission = {
      ...mockSubmission,
      feedback: 'Great work!'
    };

    (assessmentService.provideFeedback as jest.Mock).mockResolvedValue(
      mockGradedSubmission
    );

    const { getByPlaceholderText, getByText } = render(
      <GradingPanel
        submission={mockSubmission}
        onGraded={onGraded}
      />
    );

    const feedbackInput = getByPlaceholderText(
      'Provide overall feedback for the submission...'
    );
    fireEvent.change(feedbackInput, { target: { value: 'Great work!' } });

    const submitButton = getByText('Submit Feedback');
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(assessmentService.provideFeedback).toHaveBeenCalledWith(
        'sub123',
        'Great work!'
      );
      expect(onGraded).toHaveBeenCalledWith(mockGradedSubmission);
    });
  });

  it('disables submit button when feedback is empty', () => {
    const { getByText } = render(
      <GradingPanel submission={mockSubmission} />
    );

    const submitButton = getByText('Submit Feedback');
    expect(submitButton).toBeDisabled();
  });

  it('handles submission errors gracefully', async () => {
    const consoleError = jest.spyOn(console, 'error').mockImplementation();
    (assessmentService.provideFeedback as jest.Mock).mockRejectedValue(
      new Error('Failed to submit')
    );

    const { getByPlaceholderText, getByText } = render(
      <GradingPanel submission={mockSubmission} />
    );

    const feedbackInput = getByPlaceholderText(
      'Provide overall feedback for the submission...'
    );
    fireEvent.change(feedbackInput, { target: { value: 'Test feedback' } });

    const submitButton = getByText('Submit Feedback');
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(consoleError).toHaveBeenCalledWith(
        'Failed to submit grade:',
        expect.any(Error)
      );
    });

    consoleError.mockRestore();
  });
});
```