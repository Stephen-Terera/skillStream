```tsx
import { render, fireEvent, waitFor } from '@testing-library/react';
import AssessmentResults from '../AssessmentResults';
import { assessmentService } from '../../../services/assessmentService';

jest.mock('../../../services/assessmentService');

describe('AssessmentResults', () => {
  const mockSubmission = {
    id: 'sub123',
    assessmentId: 'ass123',
    userId: 'user123',
    answers: {},
    score: 85,
    startTime: '2024-03-19T10:00:00Z'
  };

  const mockAssessment = {
    title: 'Test Assessment',
    passingScore: 70,
    questions: [
      { id: 'q1', points: 50 },
      { id: 'q2', points: 50 }
    ]
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('displays correct pass status when score exceeds passing score', () => {
    const { getByText } = render(
      <AssessmentResults
        submission={mockSubmission}
        assessment={mockAssessment}
      />
    );

    expect(getByText('85.0%')).toBeInTheDocument();
    expect(getByText('Assessment Complete')).toBeInTheDocument();
  });

  it('shows retry button when failed', () => {
    const failedSubmission = { ...mockSubmission, score: 60 };
    const onRetry = jest.fn();

    const { getByText } = render(
      <AssessmentResults
        submission={failedSubmission}
        assessment={mockAssessment}
        onRetry={onRetry}
      />
    );

    const retryButton = getByText('Try Again');
    expect(retryButton).toBeInTheDocument();

    fireEvent.click(retryButton);
    expect(onRetry).toHaveBeenCalled();
  });

  it('exports to SCORM format', async () => {
    const mockUrl = 'https://example.com/scorm.zip';
    (assessmentService.exportToSCORM as jest.Mock).mockResolvedValue(mockUrl);

    const { getByText } = render(
      <AssessmentResults
        submission={mockSubmission}
        assessment={mockAssessment}
      />
    );

    const exportButton = getByText('Export SCORM');
    fireEvent.click(exportButton);

    await waitFor(() => {
      expect(assessmentService.exportToSCORM).toHaveBeenCalledWith('ass123');
    });
  });

  it('exports to xAPI format', async () => {
    const { getByText } = render(
      <AssessmentResults
        submission={mockSubmission}
        assessment={mockAssessment}
      />
    );

    const exportButton = getByText('Export xAPI');
    fireEvent.click(exportButton);

    await waitFor(() => {
      expect(assessmentService.exportToXAPI).toHaveBeenCalledWith('sub123');
    });
  });

  it('displays feedback when available', () => {
    const submissionWithFeedback = {
      ...mockSubmission,
      feedback: 'Great work on the assessment!'
    };

    const { getByText } = render(
      <AssessmentResults
        submission={submissionWithFeedback}
        assessment={mockAssessment}
      />
    );

    expect(getByText('Instructor Feedback')).toBeInTheDocument();
    expect(getByText('Great work on the assessment!')).toBeInTheDocument();
  });
});
```