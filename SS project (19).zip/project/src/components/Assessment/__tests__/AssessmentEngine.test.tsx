```tsx
import { render, fireEvent, waitFor } from '@testing-library/react';
import AssessmentEngine from '../AssessmentEngine';
import { assessmentService } from '../../../services/assessmentService';

jest.mock('../../../services/assessmentService');

describe('AssessmentEngine', () => {
  const mockAssessment = {
    id: 'test-assessment',
    title: 'Test Assessment',
    questions: [
      {
        id: 'q1',
        type: 'multiple-choice',
        content: 'What is 2+2?',
        options: ['3', '4', '5'],
        points: 1
      },
      {
        id: 'q2',
        type: 'essay',
        content: 'Explain React hooks.',
        points: 2
      }
    ],
    timeLimit: 30,
    passingScore: 70
  };

  const mockSubmission = {
    id: 'sub-123',
    assessmentId: 'test-assessment',
    answers: {},
    startTime: new Date().toISOString()
  };

  beforeEach(() => {
    jest.clearAllMocks();
    (assessmentService.startAssessment as jest.Mock).mockResolvedValue(mockSubmission);
  });

  it('starts assessment and initializes timer', async () => {
    jest.useFakeTimers();
    
    render(<AssessmentEngine assessmentId="test-assessment" />);
    
    await waitFor(() => {
      expect(assessmentService.startAssessment).toHaveBeenCalledWith('test-assessment');
    });

    // Timer should be initialized
    expect(screen.getByText('30:00')).toBeInTheDocument();
    
    // Timer should count down
    jest.advanceTimersByTime(1000);
    expect(screen.getByText('29:59')).toBeInTheDocument();
    
    jest.useRealTimers();
  });

  it('handles multiple choice questions', async () => {
    const { getByText } = render(<AssessmentEngine assessmentId="test-assessment" />);
    
    await waitFor(() => {
      expect(getByText('What is 2+2?')).toBeInTheDocument();
    });

    // Select an answer
    fireEvent.click(getByText('4'));
    
    expect(assessmentService.submitAnswer).toHaveBeenCalledWith(
      'sub-123',
      'q1',
      '4'
    );
  });

  it('handles essay questions', async () => {
    const { getByPlaceholderText } = render(
      <AssessmentEngine assessmentId="test-assessment" />
    );
    
    // Navigate to essay question
    fireEvent.click(screen.getByText('Next'));
    
    const textarea = getByPlaceholderText('Enter your answer...');
    fireEvent.change(textarea, {
      target: { value: 'React hooks are functions that...' }
    });
    
    expect(assessmentService.submitAnswer).toHaveBeenCalledWith(
      'sub-123',
      'q2',
      'React hooks are functions that...'
    );
  });

  it('shows warning for unanswered questions', async () => {
    const { getByText } = render(<AssessmentEngine assessmentId="test-assessment" />);
    
    // Go to last question without answering
    fireEvent.click(getByText('Next'));
    
    expect(getByText(/1 unanswered questions/)).toBeInTheDocument();
  });

  it('submits assessment and calls onComplete', async () => {
    const onComplete = jest.fn();
    const { getByText } = render(
      <AssessmentEngine
        assessmentId="test-assessment"
        onComplete={onComplete}
      />
    );

    // Answer all questions
    fireEvent.click(getByText('4'));
    fireEvent.click(getByText('Next'));
    
    const textarea = screen.getByPlaceholderText('Enter your answer...');
    fireEvent.change(textarea, {
      target: { value: 'Test answer' }
    });

    // Submit assessment
    fireEvent.click(getByText('Submit Assessment'));
    
    await waitFor(() => {
      expect(assessmentService.finishAssessment).toHaveBeenCalledWith('sub-123');
      expect(assessmentService.gradeSubmission).toHaveBeenCalledWith('sub-123');
      expect(onComplete).toHaveBeenCalled();
    });
  });

  it('handles errors gracefully', async () => {
    const consoleError = jest.spyOn(console, 'error').mockImplementation();
    (assessmentService.startAssessment as jest.Mock).mockRejectedValue(
      new Error('Failed to start')
    );

    render(<AssessmentEngine assessmentId="test-assessment" />);
    
    await waitFor(() => {
      expect(consoleError).toHaveBeenCalledWith(
        'Failed to load assessment:',
        expect.any(Error)
      );
    });

    consoleError.mockRestore();
  });
});
```