```tsx
import { motion } from 'framer-motion';
import { Award, Download, Share2, CheckCircle, XCircle } from 'lucide-react';
import { assessmentService } from '../../services/assessmentService';
import type { Submission } from '../../services/assessmentService';

interface Props {
  submission: Submission;
  assessment: {
    title: string;
    passingScore: number;
    questions: Array<{ id: string; points: number }>;
  };
  onRetry?: () => void;
}

export default function AssessmentResults({ submission, assessment, onRetry }: Props) {
  const totalPoints = assessment.questions.reduce((sum, q) => sum + q.points, 0);
  const score = submission.score || 0;
  const percentage = (score / totalPoints) * 100;
  const passed = percentage >= assessment.passingScore;

  const exportToSCORM = async () => {
    try {
      const url = await assessmentService.exportToSCORM(submission.assessmentId);
      window.open(url, '_blank');
    } catch (error) {
      console.error('Failed to export SCORM package:', error);
    }
  };

  const exportToXAPI = async () => {
    try {
      const statement = await assessmentService.exportToXAPI(submission.id);
      console.log('xAPI statement generated:', statement);
    } catch (error) {
      console.error('Failed to export xAPI statement:', error);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="cosmic-card"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            {passed ? (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center"
              >
                <CheckCircle className="w-8 h-8 text-green-400" />
              </motion.div>
            ) : (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center"
              >
                <XCircle className="w-8 h-8 text-red-400" />
              </motion.div>
            )}
          </div>
          <h2 className="text-2xl font-bold mb-2">{assessment.title}</h2>
          <p className="text-gray-400">Assessment Complete</p>
        </div>

        {/* Score */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span>Your Score</span>
            <span className="text-2xl font-bold">{percentage.toFixed(1)}%</span>
          </div>
          <div className="h-4 bg-blue-500/20 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${percentage}%` }}
              className={`h-full ${
                passed ? 'bg-green-500' : 'bg-red-500'
              }`}
            />
          </div>
          <p className="text-sm text-gray-400 mt-2">
            Passing score: {assessment.passingScore}%
          </p>
        </div>

        {/* Feedback */}
        {submission.feedback && (
          <div className="mb-8 p-4 rounded-lg bg-blue-500/10">
            <h3 className="font-semibold mb-2">Instructor Feedback</h3>
            <p className="text-gray-300">{submission.feedback}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-wrap gap-4">
          {!passed && (
            <button onClick={onRetry} className="cosmic-button">
              <Award className="w-4 h-4 mr-2" />
              Try Again
            </button>
          )}
          
          <button onClick={exportToSCORM} className="cosmic-button">
            <Download className="w-4 h-4 mr-2" />
            Export SCORM
          </button>
          
          <button onClick={exportToXAPI} className="cosmic-button">
            <Share2 className="w-4 h-4 mr-2" />
            Export xAPI
          </button>
        </div>
      </motion.div>
    </div>
  );
}
```