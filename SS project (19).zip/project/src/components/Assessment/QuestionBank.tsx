```tsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, Plus, Edit2, Copy, Trash2, Tag } from 'lucide-react';
import type { Question } from '../../services/assessmentService';

interface Props {
  questions: Question[];
  onAddQuestion: (question: Question) => void;
  onEditQuestion: (question: Question) => void;
  onDeleteQuestion: (questionId: string) => void;
  onDuplicateQuestion: (questionId: string) => void;
}

export default function QuestionBank({
  questions,
  onAddQuestion,
  onEditQuestion,
  onDeleteQuestion,
  onDuplicateQuestion
}: Props) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<Question['type'] | 'all'>('all');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const allTags = Array.from(
    new Set(questions.flatMap(q => q.tags || []))
  );

  const filteredQuestions = questions.filter(question => {
    const matchesSearch = question.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || question.type === selectedType;
    const matchesTags = selectedTags.length === 0 || 
      selectedTags.every(tag => question.tags?.includes(tag));
    
    return matchesSearch && matchesType && matchesTags;
  });

  const toggleTag = (tag: string) => {
    setSelectedTags(prev =>
      prev.includes(tag)
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Question Bank</h2>
        <button
          onClick={() => onAddQuestion({
            id: Date.now().toString(),
            type: 'multiple-choice',
            content: '',
            points: 1,
            tags: []
          })}
          className="cosmic-button"
        >
          <Plus size={20} />
          <span>Add Question</span>
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search questions..."
            className="cosmic-input w-full pl-10"
          />
        </div>

        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value as Question['type'] | 'all')}
          className="cosmic-input"
        >
          <option value="all">All Types</option>
          <option value="multiple-choice">Multiple Choice</option>
          <option value="essay">Essay</option>
          <option value="coding">Coding</option>
        </select>

        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <select
            multiple
            value={selectedTags}
            onChange={(e) => setSelectedTags(Array.from(e.target.selectedOptions, option => option.value))}
            className="cosmic-input w-full pl-10"
          >
            {allTags.map(tag => (
              <option key={tag} value={tag}>{tag}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tag Cloud */}
      <div className="flex flex-wrap gap-2 mb-6">
        {allTags.map(tag => (
          <button
            key={tag}
            onClick={() => toggleTag(tag)}
            className={`flex items-center space-x-1 px-3 py-1 rounded-full transition-colors ${
              selectedTags.includes(tag)
                ? 'bg-blue-500 text-white'
                : 'bg-blue-500/10 hover:bg-blue-500/20'
            }`}
          >
            <Tag size={16} />
            <span>{tag}</span>
          </button>
        ))}
      </div>

      {/* Questions List */}
      <AnimatePresence>
        <div className="space-y-4">
          {filteredQuestions.map((question) => (
            <motion.div
              key={question.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="cosmic-card"
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="px-2 py-1 text-sm rounded-full bg-blue-500/10 text-blue-400">
                      {question.type}
                    </span>
                    <span className="text-sm text-gray-400">
                      {question.points} point{question.points !== 1 && 's'}
                    </span>
                  </div>
                  <p className="text-lg mb-4">{question.content}</p>
                  {question.tags && question.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {question.tags.map(tag => (
                        <span
                          key={tag}
                          className="px-2 py-1 text-sm rounded-full bg-blue-500/10 text-blue-400"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => onEditQuestion(question)}
                    className="cosmic-button"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={() => onDuplicateQuestion(question.id)}
                    className="cosmic-button"
                  >
                    <Copy size={18} />
                  </button>
                  <button
                    onClick={() => onDeleteQuestion(question.id)}
                    className="cosmic-button text-red-400 hover:text-red-300"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </AnimatePresence>
    </div>
  );
}
```