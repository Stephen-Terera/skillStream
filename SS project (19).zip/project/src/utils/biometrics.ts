import { Biometrics } from '@nativescript/biometrics';
import { FingerprintAuth } from '@nativescript/fingerprint-auth';

export class BiometricManager {
  private biometrics: Biometrics;
  private fingerprintAuth: FingerprintAuth;

  constructor() {
    this.biometrics = new Biometrics();
    this.fingerprintAuth = new FingerprintAuth();
  }

  async isBiometricAvailable(): Promise<boolean> {
    try {
      const result = await this.biometrics.available();
      return result.biometrics;
    } catch (error) {
      console.error('Biometric availability check failed:', error);
      return false;
    }
  }

  async authenticate(reason: string = 'Verify your identity'): Promise<boolean> {
    try {
      const result = await this.biometrics.verifyFingerprint({
        title: 'SkillStream Authentication',
        message: reason,
        fallbackMessage: 'Use PIN instead'
      });
      return result.code === 0;
    } catch (error) {
      console.error('Biometric authentication failed:', error);
      return false;
    }
  }

  async enrollFingerprint(): Promise<boolean> {
    try {
      const available = await this.fingerprintAuth.available();
      if (!available) {
        throw new Error('Fingerprint enrollment not available');
      }
      
      const result = await this.fingerprintAuth.verifyFingerprintWithCustomFallback({
        message: 'Scan your fingerprint to enroll',
        fallbackMessage: 'Use alternative method',
        authenticationValidityDuration: 10
      });
      
      return result.success;
    } catch (error) {
      console.error('Fingerprint enrollment failed:', error);
      return false;
    }
  }
}