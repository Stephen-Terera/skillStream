import { Application, AndroidApplication, Utils } from '@nativescript/core';
import { BehaviorSubject, Observable } from 'rxjs';

export class DeeplinkManager {
  private static instance: DeeplinkManager;
  private deeplinkSubject: BehaviorSubject<string | null>;

  private constructor() {
    this.deeplinkSubject = new BehaviorSubject<string | null>(null);
    this.setupDeeplinkHandling();
  }

  static getInstance(): DeeplinkManager {
    if (!DeeplinkManager.instance) {
      DeeplinkManager.instance = new DeeplinkManager();
    }
    return DeeplinkManager.instance;
  }

  private setupDeeplinkHandling(): void {
    if (global.android) {
      Application.android.on(AndroidApplication.activityNewIntentEvent, (args: any) => {
        const intent = args.intent;
        if (intent) {
          const action = intent.getAction();
          const data = intent.getData();
          
          if (action === android.content.Intent.ACTION_VIEW && data) {
            this.handleDeeplink(data.toString());
          }
        }
      });
    } else if (global.ios) {
      // iOS deeplink handling
      const appDelegate = UIApplicationDelegate.extend({
        applicationOpenURLOptions(application: UIApplication, url: NSURL, options: NSDictionary<string, any>): boolean {
          this.handleDeeplink(url.absoluteString);
          return true;
        },
        
        applicationContinueUserActivityRestorationHandler(application: UIApplication, userActivity: NSUserActivity, handler: (p1: NSArray<any>) => void): boolean {
          if (userActivity.activityType === NSUserActivityTypeBrowsingWeb) {
            const url = userActivity.webpageURL;
            if (url) {
              this.handleDeeplink(url.absoluteString);
            }
          }
          return true;
        }
      }, {
        name: 'CustomAppDelegate',
        protocols: [UIApplicationDelegate]
      });
    }
  }

  private handleDeeplink(url: string): void {
    this.deeplinkSubject.next(url);
  }

  onDeeplink(): Observable<string | null> {
    return this.deeplinkSubject.asObservable();
  }

  parseDeeplink(url: string): { 
    route: string;
    params: Record<string, string>;
  } {
    try {
      const urlObj = new URL(url);
      const pathSegments = urlObj.pathname.split('/').filter(Boolean);
      const params = Object.fromEntries(urlObj.searchParams);

      return {
        route: `/${pathSegments.join('/')}`,
        params
      };
    } catch (error) {
      console.error('Error parsing deeplink:', error);
      return { route: '/', params: {} };
    }
  }
}