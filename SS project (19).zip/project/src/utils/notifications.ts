import { LocalNotifications } from '@nativescript/local-notifications';
import { PushNotifications } from '@nativescript/push-notifications';

class NotificationManager {
  async scheduleLocalNotification(title: string, body: string, at: Date) {
    return LocalNotifications.schedule([{
      id: Date.now(),
      title,
      body,
      at,
      forceShowWhenInForeground: true,
    }]);
  }

  async scheduleCourseReminder(courseId: string, courseName: string, startTime: Date) {
    return this.scheduleLocalNotification(
      'Course Reminder',
      `Your course "${courseName}" starts in 15 minutes!`,
      new Date(startTime.getTime() - 15 * 60000)
    );
  }

  async registerPushNotifications(userId: string) {
    try {
      const token = await PushNotifications.register({
        showNotifications: true,
        showNotificationsWhenInForeground: true,
      });

      // Send token to your backend
      // await api.registerPushToken(userId, token);

      return token;
    } catch (error) {
      console.error('Error registering push notifications:', error);
      throw error;
    }
  }

  onPushNotificationReceived(callback: (notification: any) => void) {
    PushNotifications.addOnMessageReceivedCallback(callback);
  }
}

export const notificationManager = new NotificationManager();