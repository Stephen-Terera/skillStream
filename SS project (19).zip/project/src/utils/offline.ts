import { BackgroundHttp } from '@nativescript/background-http';
import { knownFolders, path } from '@nativescript/core';
import { getString, setString } from '@nativescript/core/application-settings';

interface SyncItem {
  id: string;
  type: 'course' | 'note' | 'progress';
  data: any;
  timestamp: number;
  synced: boolean;
}

class OfflineManager {
  private syncQueue: SyncItem[] = [];
  private readonly SYNC_QUEUE_KEY = 'offline_sync_queue';
  private readonly CONTENT_DIR = path.join(knownFolders.documents().path, 'offline_content');

  constructor() {
    this.loadSyncQueue();
  }

  private loadSyncQueue() {
    const queueData = getString(this.SYNC_QUEUE_KEY);
    if (queueData) {
      this.syncQueue = JSON.parse(queueData);
    }
  }

  private saveSyncQueue() {
    setString(this.SYNC_QUEUE_KEY, JSON.stringify(this.syncQueue));
  }

  async saveCourseOffline(courseId: string, courseData: any) {
    const coursePath = path.join(this.CONTENT_DIR, `course_${courseId}.json`);
    try {
      await knownFolders.documents().writeText(coursePath, JSON.stringify(courseData));
      return true;
    } catch (error) {
      console.error('Error saving course offline:', error);
      return false;
    }
  }

  async loadOfflineCourse(courseId: string) {
    const coursePath = path.join(this.CONTENT_DIR, `course_${courseId}.json`);
    try {
      const content = await knownFolders.documents().readText(coursePath);
      return JSON.parse(content);
    } catch (error) {
      console.error('Error loading offline course:', error);
      return null;
    }
  }

  queueProgressUpdate(progressData: any) {
    const syncItem: SyncItem = {
      id: Date.now().toString(),
      type: 'progress',
      data: progressData,
      timestamp: Date.now(),
      synced: false
    };
    this.syncQueue.push(syncItem);
    this.saveSyncQueue();
  }

  async syncProgress() {
    const unsynced = this.syncQueue.filter(item => !item.synced);
    for (const item of unsynced) {
      try {
        // Implement your API call here
        // await api.updateProgress(item.data);
        item.synced = true;
      } catch (error) {
        console.error('Error syncing progress:', error);
      }
    }
    this.saveSyncQueue();
  }

  async downloadCourseContent(courseId: string, mediaUrls: string[]) {
    const session = BackgroundHttp.session('course-download');
    
    for (const url of mediaUrls) {
      const filename = path.basename(url);
      const localPath = path.join(this.CONTENT_DIR, courseId, filename);
      
      await new Promise((resolve, reject) => {
        const request = {
          url,
          method: 'GET',
          description: `Downloading ${filename}`,
          androidAutoDeleteAfterUpload: false,
          androidNotificationTitle: 'Downloading course content'
        };

        const task = session.downloadFile(request, localPath);
        
        task.on('progress', (progress) => {
          console.log(`Progress: ${progress.currentBytes}/${progress.totalBytes}`);
        });

        task.on('complete', resolve);
        task.on('error', reject);
      });
    }
  }
}

export const offlineManager = new OfflineManager();