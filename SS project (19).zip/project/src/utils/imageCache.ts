import { ImageCache } from '@nativescript/core/image-cache';
import { knownFolders, path } from '@nativescript/core';

class ImageCacheManager {
  private cache: ImageCache;
  private readonly maxCacheAge = 7 * 24 * 60 * 60 * 1000; // 7 days

  constructor() {
    this.cache = new ImageCache();
    this.cache.maxRequests = 5;
    this.cache.enableDownload();

    // Set up cache directory
    const cacheDir = path.join(knownFolders.documents().path, 'image_cache');
    this.cache.setCacheFolder(cacheDir);
  }

  async preloadImage(url: string): Promise<string> {
    try {
      const cachedPath = await this.cache.get(url);
      return cachedPath || url;
    } catch (error) {
      console.error('Error preloading image:', error);
      return url;
    }
  }

  async preloadImages(urls: string[]): Promise<void> {
    await Promise.all(urls.map(url => this.preloadImage(url)));
  }

  clearCache(): void {
    this.cache.clear();
  }

  clearOldCache(): void {
    const now = Date.now();
    this.cache.entries.forEach(entry => {
      if (now - entry.lastAccess > this.maxCacheAge) {
        this.cache.remove(entry.key);
      }
    });
  }
}

export const imageCacheManager = new ImageCacheManager();