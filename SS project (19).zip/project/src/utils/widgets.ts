import { AppShortcuts } from '@nativescript/app-shortcuts';
import { Application, Utils } from '@nativescript/core';

export class WidgetManager {
  private shortcuts: AppShortcuts;

  constructor() {
    this.shortcuts = new AppShortcuts();
  }

  async setupQuickActions(): Promise<void> {
    try {
      await this.shortcuts.setQuickActionItems([
        {
          type: 'courses',
          title: 'My Courses',
          subtitle: 'View your enrolled courses',
          icon: Utils.isAndroid ? 'ic_courses' : 'courses'
        },
        {
          type: 'study',
          title: 'Study Groups',
          subtitle: 'Join a study session',
          icon: Utils.isAndroid ? 'ic_study' : 'study'
        },
        {
          type: 'notes',
          title: 'Quick Note',
          subtitle: 'Create a new note',
          icon: Utils.isAndroid ? 'ic_note' : 'note'
        }
      ]);
    } catch (error) {
      console.error('Error setting up quick actions:', error);
    }
  }

  async updateWidget(widgetId: string, data: any): Promise<void> {
    if (Utils.isAndroid) {
      // Android widget update
      const context = Utils.android.getApplicationContext();
      const intent = new android.content.Intent(context, com.skillstream.widget.SkillStreamWidget.class);
      intent.setAction(android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE);
      
      const ids = [parseInt(widgetId)];
      intent.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
      intent.putExtra('widgetData', JSON.stringify(data));
      
      context.sendBroadcast(intent);
    } else if (Utils.ios) {
      // iOS widget update
      const userDefaults = NSUserDefaults.standardUserDefaults;
      userDefaults.setObjectForKey(data, `widget_${widgetId}`);
      userDefaults.synchronize();
      
      if (Application.ios.widgetController) {
        Application.ios.widgetController.reloadTimelines();
      }
    }
  }
}