import { 
  requestPermissions as requestCameraPermissions,
  takePicture,
  isAvailable 
} from '@nativescript/camera';
import { 
  getCurrentLocation,
  enableLocationRequest 
} from '@nativescript/geolocation';
import { LocalNotifications } from '@nativescript/local-notifications';
import { PushNotifications } from '@nativescript/push-notifications';

export async function requestCameraAccess() {
  if (!isAvailable()) {
    throw new Error('Camera not available');
  }
  return requestCameraPermissions();
}

export async function requestLocationAccess() {
  return enableLocationRequest();
}

export async function requestNotificationPermissions() {
  try {
    // Local notifications
    await LocalNotifications.requestPermission();
    
    // Push notifications
    await PushNotifications.register({
      showNotifications: true,
      showNotificationsWhenInForeground: true,
    });
    
    return true;
  } catch (error) {
    console.error('Error requesting notification permissions:', error);
    return false;
  }
}