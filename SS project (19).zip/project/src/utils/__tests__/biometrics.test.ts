import { BiometricManager } from '../biometrics';
import { Biometrics } from '@nativescript/biometrics';
import { FingerprintAuth } from '@nativescript/fingerprint-auth';

jest.mock('@nativescript/biometrics');
jest.mock('@nativescript/fingerprint-auth');

describe('BiometricManager', () => {
  let biometricManager: BiometricManager;
  let mockBiometrics: jest.Mocked<Biometrics>;
  let mockFingerprintAuth: jest.Mocked<FingerprintAuth>;

  beforeEach(() => {
    mockBiometrics = new Biometrics() as jest.Mocked<Biometrics>;
    mockFingerprintAuth = new FingerprintAuth() as jest.Mocked<FingerprintAuth>;
    biometricManager = new BiometricManager();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('isBiometricAvailable', () => {
    it('should return true when biometrics are available', async () => {
      mockBiometrics.available.mockResolvedValue({ biometrics: true });
      
      const result = await biometricManager.isBiometricAvailable();
      
      expect(result).toBe(true);
      expect(mockBiometrics.available).toHaveBeenCalled();
    });

    it('should return false when biometrics are not available', async () => {
      mockBiometrics.available.mockResolvedValue({ biometrics: false });
      
      const result = await biometricManager.isBiometricAvailable();
      
      expect(result).toBe(false);
    });

    it('should handle errors gracefully', async () => {
      mockBiometrics.available.mockRejectedValue(new Error('Hardware error'));
      
      const result = await biometricManager.isBiometricAvailable();
      
      expect(result).toBe(false);
    });
  });

  describe('authenticate', () => {
    it('should authenticate successfully', async () => {
      mockBiometrics.verifyFingerprint.mockResolvedValue({ code: 0 });
      
      const result = await biometricManager.authenticate('Test reason');
      
      expect(result).toBe(true);
      expect(mockBiometrics.verifyFingerprint).toHaveBeenCalledWith({
        title: 'SkillStream Authentication',
        message: 'Test reason',
        fallbackMessage: 'Use PIN instead'
      });
    });

    it('should handle authentication failure', async () => {
      mockBiometrics.verifyFingerprint.mockResolvedValue({ code: 1 });
      
      const result = await biometricManager.authenticate();
      
      expect(result).toBe(false);
    });
  });

  describe('enrollFingerprint', () => {
    it('should enroll fingerprint successfully', async () => {
      mockFingerprintAuth.available.mockResolvedValue(true);
      mockFingerprintAuth.verifyFingerprintWithCustomFallback.mockResolvedValue({ success: true });
      
      const result = await biometricManager.enrollFingerprint();
      
      expect(result).toBe(true);
      expect(mockFingerprintAuth.verifyFingerprintWithCustomFallback).toHaveBeenCalled();
    });

    it('should handle enrollment failure when not available', async () => {
      mockFingerprintAuth.available.mockResolvedValue(false);
      
      const result = await biometricManager.enrollFingerprint();
      
      expect(result).toBe(false);
    });
  });
});