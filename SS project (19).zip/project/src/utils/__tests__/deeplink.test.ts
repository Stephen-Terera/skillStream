import { DeeplinkManager } from '../deeplink';
import { Application, AndroidApplication } from '@nativescript/core';

jest.mock('@nativescript/core');

describe('DeeplinkManager', () => {
  let deeplinkManager: DeeplinkManager;

  beforeEach(() => {
    jest.clearAllMocks();
    deeplinkManager = DeeplinkManager.getInstance();
  });

  describe('getInstance', () => {
    it('should return the same instance', () => {
      const instance1 = DeeplinkManager.getInstance();
      const instance2 = DeeplinkManager.getInstance();
      
      expect(instance1).toBe(instance2);
    });
  });

  describe('parseDeeplink', () => {
    it('should parse valid deeplink URL', () => {
      const url = 'skillstream://courses/123?section=overview';
      const result = deeplinkManager.parseDeeplink(url);
      
      expect(result).toEqual({
        route: '/courses/123',
        params: { section: 'overview' }
      });
    });

    it('should handle invalid URLs', () => {
      const url = 'invalid-url';
      const result = deeplinkManager.parseDeeplink(url);
      
      expect(result).toEqual({
        route: '/',
        params: {}
      });
    });

    it('should parse URLs with multiple parameters', () => {
      const url = 'skillstream://study-groups/456?type=web&level=advanced';
      const result = deeplinkManager.parseDeeplink(url);
      
      expect(result).toEqual({
        route: '/study-groups/456',
        params: {
          type: 'web',
          level: 'advanced'
        }
      });
    });
  });

  describe('onDeeplink', () => {
    it('should emit deeplink URLs', (done) => {
      const testUrl = 'skillstream://test';
      
      deeplinkManager.onDeeplink().subscribe(url => {
        if (url === testUrl) {
          expect(url).toBe(testUrl);
          done();
        }
      });

      // Simulate Android intent
      if (global.android) {
        const mockIntent = {
          getAction: () => android.content.Intent.ACTION_VIEW,
          getData: () => ({ toString: () => testUrl })
        };

        Application.android.emit(
          AndroidApplication.activityNewIntentEvent,
          { intent: mockIntent }
        );
      }
    });
  });
});