import { render, fireEvent, waitFor } from '@testing-library/react-native';
import ChatPage from '../../pages/ChatPage.native';
import { offlineManager } from '../../utils/offline';
import { notificationManager } from '../../utils/notifications';

jest.mock('../../utils/offline');
jest.mock('../../utils/notifications');

describe('ChatPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should load cached messages on mount', async () => {
    const mockMessages = [
      { id: '1', text: 'Test message', sender: 'user1', timestamp: '2024-03-19T10:00:00Z' }
    ];
    
    offlineManager.loadOfflineData.mockResolvedValue(mockMessages);
    
    const { findByText } = render(<ChatPage />);
    
    expect(await findByText('Test message')).toBeTruthy();
    expect(offlineManager.loadOfflineData).toHaveBeenCalledWith('chat_messages');
  });

  it('should send message when online', async () => {
    const { getByPlaceholderText, getByText } = render(<ChatPage />);
    
    fireEvent.changeText(getByPlaceholderText('Type a message...'), 'Hello');
    fireEvent.press(getByText('Send'));
    
    await waitFor(() => {
      expect(offlineManager.queueForSync).not.toHaveBeenCalled();
    });
  });

  it('should queue message for sync when offline', async () => {
    const { getByPlaceholderText, getByText } = render(<ChatPage />);
    
    // Simulate offline state
    fireEvent.changeText(getByPlaceholderText('Type a message...'), 'Offline message');
    fireEvent.press(getByText('Send'));
    
    await waitFor(() => {
      expect(offlineManager.queueForSync).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'chat_message',
          action: 'send'
        })
      );
    });
  });

  it('should handle push notifications', async () => {
    render(<ChatPage />);
    
    expect(notificationManager.registerPushNotifications).toHaveBeenCalled();
    
    // Simulate receiving a push notification
    const mockCallback = notificationManager.onPushNotificationReceived.mock.calls[0][0];
    mockCallback({
      type: 'chat_message',
      messageId: '123',
      message: 'New message',
      senderId: 'user2'
    });
    
    await waitFor(() => {
      expect(screen.getByText('New message')).toBeTruthy();
    });
  });
});