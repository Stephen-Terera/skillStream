import { WidgetManager } from '../widgets';
import { AppShortcuts } from '@nativescript/app-shortcuts';
import { Utils, Application } from '@nativescript/core';

jest.mock('@nativescript/app-shortcuts');
jest.mock('@nativescript/core');

describe('WidgetManager', () => {
  let widgetManager: WidgetManager;
  let mockShortcuts: jest.Mocked<AppShortcuts>;

  beforeEach(() => {
    mockShortcuts = new AppShortcuts() as jest.Mocked<AppShortcuts>;
    widgetManager = new WidgetManager();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('setupQuickActions', () => {
    it('should set up quick action items successfully', async () => {
      await widgetManager.setupQuickActions();

      expect(mockShortcuts.setQuickActionItems).toHaveBeenCalledWith(
        expect.arrayContaining([
          expect.objectContaining({
            type: 'courses',
            title: 'My Courses'
          }),
          expect.objectContaining({
            type: 'study',
            title: 'Study Groups'
          }),
          expect.objectContaining({
            type: 'notes',
            title: 'Quick Note'
          })
        ])
      );
    });

    it('should handle setup errors gracefully', async () => {
      const consoleError = jest.spyOn(console, 'error');
      mockShortcuts.setQuickActionItems.mockRejectedValue(new Error('Setup failed'));

      await widgetManager.setupQuickActions();

      expect(consoleError).toHaveBeenCalledWith(
        'Error setting up quick actions:',
        expect.any(Error)
      );
    });
  });

  describe('updateWidget', () => {
    it('should update Android widget correctly', async () => {
      Utils.isAndroid = true;
      const mockContext = {
        sendBroadcast: jest.fn()
      };
      Utils.android.getApplicationContext.mockReturnValue(mockContext);

      await widgetManager.updateWidget('123', { data: 'test' });

      expect(mockContext.sendBroadcast).toHaveBeenCalled();
    });

    it('should update iOS widget correctly', async () => {
      Utils.isAndroid = false;
      Utils.ios = true;
      const mockUserDefaults = {
        setObjectForKey: jest.fn(),
        synchronize: jest.fn()
      };
      global.NSUserDefaults = {
        standardUserDefaults: mockUserDefaults
      };

      await widgetManager.updateWidget('123', { data: 'test' });

      expect(mockUserDefaults.setObjectForKey).toHaveBeenCalledWith(
        { data: 'test' },
        'widget_123'
      );
      expect(mockUserDefaults.synchronize).toHaveBeenCalled();
    });
  });
});