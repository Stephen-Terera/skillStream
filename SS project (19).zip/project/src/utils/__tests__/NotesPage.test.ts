import { render, fireEvent } from '@testing-library/react-native';
import NotesPage from '../../pages/NotesPage.native';
import { offlineManager } from '../../utils/offline';
import { biometricManager } from '../../utils/biometrics';

jest.mock('../../utils/offline');
jest.mock('../../utils/biometrics');

describe('NotesPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should load cached notes on mount', async () => {
    const mockNotes = [
      { id: '1', title: 'Test Note', content: 'Content' }
    ];
    
    offlineManager.loadOfflineData.mockResolvedValue(mockNotes);
    
    const { findByText } = render(<NotesPage />);
    
    expect(await findByText('Test Note')).toBeTruthy();
    expect(offlineManager.loadOfflineData).toHaveBeenCalledWith('notes');
  });

  it('should handle biometric authentication', async () => {
    biometricManager.isBiometricAvailable.mockResolvedValue(true);
    biometricManager.authenticate.mockResolvedValue(true);
    
    render(<NotesPage />);
    
    expect(biometricManager.isBiometricAvailable).toHaveBeenCalled();
    expect(biometricManager.authenticate).toHaveBeenCalledWith(
      'Authenticate to access your notes'
    );
  });

  it('should save notes offline', async () => {
    const { getByText, getByPlaceholderText } = render(<NotesPage />);
    
    // Open new note form
    fireEvent.press(getByText('+'));
    
    // Fill in note details
    fireEvent.changeText(getByPlaceholderText('Note title'), 'New Note');
    fireEvent.changeText(getByPlaceholderText('Note content'), 'Test content');
    
    // Save note
    fireEvent.press(getByText('Save'));
    
    expect(offlineManager.saveOfflineData).toHaveBeenCalled();
    expect(offlineManager.queueForSync).toHaveBeenCalled();
  });
});