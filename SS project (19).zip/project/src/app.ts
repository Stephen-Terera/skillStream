import { Application } from '@nativescript/core';
import { MainNavigator } from './components/navigation/MainNavigator';
import { Provider } from 'react-redux';
import { store } from './store/store';

Application.run({
  create: () => {
    return (
      <Provider store={store}>
        <MainNavigator />
      </Provider>
    );
  }
});