import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import ParticleBackground from './components/ParticleBackground';
import LoadingScreen from './components/LoadingScreen';
import PrivateRoute from './components/PrivateRoute';

// Pages
import HomePage from './pages/HomePage';
import CoursesPage from './pages/CoursesPage';
import TutorsPage from './pages/TutorsPage';
import ChatPage from './pages/ChatPage';
import DashboardPage from './pages/DashboardPage';
import SkillMapPage from './pages/SkillMapPage';
import StudyGroupsPage from './pages/StudyGroupsPage';
import NotesPage from './pages/NotesPage';
import PreferencesPage from './pages/PreferencesPage';
import AuthPage from './pages/AuthPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsOfServicePage from './pages/TermsOfServicePage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import SubscriptionPage from './pages/SubscriptionPage';

import type { RootState } from './store/store';

// ScrollToTop component to handle navigation
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  const [initialLoading, setInitialLoading] = useState(true);
  const { isLoading, accessibility, display } = useSelector((state: RootState) => state.userPreferences);
  const { token } = useSelector((state: RootState) => state.auth);

  useEffect(() => {
    const timer = setTimeout(() => {
      setInitialLoading(false);
    }, 4500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('high-contrast', accessibility.highContrast);
    document.documentElement.classList.toggle('reduce-motion', accessibility.reducedMotion);
    document.documentElement.classList.remove('text-sm', 'text-base', 'text-lg');
    document.documentElement.classList.add({
      'small': 'text-sm',
      'medium': 'text-base',
      'large': 'text-lg'
    }[accessibility.fontSize]);
    document.documentElement.classList.toggle('light', display.theme === 'light');
  }, [accessibility, display]);

  if (initialLoading || isLoading) {
    return <LoadingScreen />;
  }

  return (
    <Router>
      <ScrollToTop />
      <div className="relative min-h-screen">
        <ParticleBackground />
        <div className="relative z-10">
          <Navigation />
          <main className="min-h-[calc(100vh-4rem)]">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/auth" element={<AuthPage />} />
              
              {/* Protected Routes */}
              <Route path="/courses" element={
                <PrivateRoute>
                  <CoursesPage />
                </PrivateRoute>
              } />
              <Route path="/tutors" element={
                <PrivateRoute>
                  <TutorsPage />
                </PrivateRoute>
              } />
              <Route path="/chat" element={
                <PrivateRoute>
                  <ChatPage />
                </PrivateRoute>
              } />
              <Route path="/dashboard" element={
                <PrivateRoute>
                  <DashboardPage />
                </PrivateRoute>
              } />
              <Route path="/skillmap" element={
                <PrivateRoute>
                  <SkillMapPage />
                </PrivateRoute>
              } />
              <Route path="/study-groups" element={
                <PrivateRoute>
                  <StudyGroupsPage />
                </PrivateRoute>
              } />
              <Route path="/notes" element={
                <PrivateRoute>
                  <NotesPage />
                </PrivateRoute>
              } />
              <Route path="/preferences" element={
                <PrivateRoute>
                  <PreferencesPage />
                </PrivateRoute>
              } />
              <Route path="/subscription" element={
                <PrivateRoute>
                  <SubscriptionPage />
                </PrivateRoute>
              } />

              {/* Public Routes */}
              <Route path="/privacy" element={<PrivacyPolicyPage />} />
              <Route path="/terms" element={<TermsOfServicePage />} />
              <Route path="/cookies" element={<CookiePolicyPage />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </div>
    </Router>
  );
}