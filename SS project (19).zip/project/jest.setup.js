// Mock NativeScript core modules
global.android = {};
global.ios = {};
global.UIApplicationDelegate = {
  extend: () => ({})
};
global.NSUserDefaults = {
  standardUserDefaults: {}
};

// Mock NativeScript application module
jest.mock('@nativescript/core', () => ({
  Application: {
    android: {
      on: jest.fn(),
      emit: jest.fn()
    },
    ios: {
      widgetController: {
        reloadTimelines: jest.fn()
      }
    }
  },
  AndroidApplication: {
    activityNewIntentEvent: 'activityNewIntentEvent'
  },
  Utils: {
    isAndroid: false,
    ios: false,
    android: {
      getApplicationContext: jest.fn()
    }
  }
}));

// Mock other NativeScript modules
jest.mock('@nativescript/biometrics', () => ({
  Biometrics: jest.fn().mockImplementation(() => ({
    available: jest.fn(),
    verifyFingerprint: jest.fn()
  }))
}));

jest.mock('@nativescript/fingerprint-auth', () => ({
  FingerprintAuth: jest.fn().mockImplementation(() => ({
    available: jest.fn(),
    verifyFingerprintWithCustomFallback: jest.fn()
  }))
}));

jest.mock('@nativescript/app-shortcuts', () => ({
  AppShortcuts: jest.fn().mockImplementation(() => ({
    setQuickActionItems: jest.fn()
  }))
}));