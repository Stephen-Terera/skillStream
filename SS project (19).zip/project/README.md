# SkillStream Mobile

A NativeScript-based mobile application for the SkillStream learning platform.

## Running in StackBlitz

1. The application will automatically set up the NativeScript environment when you run any of the npm scripts.

2. Start the application in preview mode:
```bash
npm start
```

This will:
- Set up the NativeScript environment
- Start the preview server
- Open the preview in a new window

## Features

- Offline-first architecture
- Biometric authentication
- Deep linking support
- Widget integration
- Push notifications
- Background sync
- Geolocation services
- Camera integration

## Project Structure

- `/src/components` - React components
- `/src/pages` - Application pages
- `/src/utils` - Utility functions and services
- `/src/store` - Redux store and slices
- `/src/types` - TypeScript type definitions

## Testing

Tests are written using Jest and React Native Testing Library. Run tests with:

```bash
npm test
```

## Development Notes

- The application uses NativeScript with React for native mobile development
- All native features are properly abstracted in the utils directory
- Full offline support with background sync
- Comprehensive test coverage
- Platform-specific UI components when needed